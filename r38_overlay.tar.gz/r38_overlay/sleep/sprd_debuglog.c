/*
 * sprd_debuglog.c - W527 sleep monitor framework (factory-spec port, r38)
 *
 * Factory symbol surface (census_group_睡眠监控框架_state_check_.txt):
 *   ap_sleep_condition_check   - condition/PM register dump (recon'd from
 *                                factory binary @0xffffff8008443cd0, 280B,
 *                                control flow 100%)
 *   sleep_ctrl                 - framework control (sysfs /sys/kernel/sleep_ctrl)
 *   sleep_notifier             - blocking notifier head, fired on suspend paths
 *   sleep_notifier_block       - pm_notifier block bridging PM -> sleep_notifier
 *   wakeup_info                - wake source registry type
 *   wakeup_info_register/_unregister
 *   sprd_debuglog_driver(+_init/_exit) - built-in driver entry
 *
 * No userspace ABI dependency found in factory (no __ksymtab exports) - this
 * is an internal diagnostics framework; re-implementation matches symbol
 * names and print formats ("###--POWER DOMAIN STATE", "##--%s.%s: 0x%08x").
 */

#include <linux/module.h>
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/platform_device.h>
#include <linux/of.h>
#include <linux/regmap.h>
#include <linux/mfd/syscon.h>
#include <linux/list.h>
#include <linux/mutex.h>
#include <linux/slab.h>
#include <linux/suspend.h>
#include <linux/notifier.h>
#include <linux/kobject.h>
#include <linux/string.h>

/* ---- recon'd structures (factory binary) ---- */
struct sleep_cond_entry {
	const char *name;	/* +0x00 condition name (print) */
	const char *syscon_prop; /* +0x08 syscon phandle property name */
	u32 reg_addr;		/* +0x10 register address */
	u32 flag;		/* +0x18 bit flags (0 = print only, no read) */
};

struct sleep_cond_ctx {
	void *unused;			/* +0x00 */
	struct sleep_cond_entry *head;	/* entries array */
	int count;			/* entry count */
	struct device_node *np;		/* node for syscon lookup */
};

/* ---- wakeup_info registry ---- */
struct wakeup_info {
	const char *name;
	struct device *dev;
	struct list_head node;
};

static LIST_HEAD(wakeup_info_list);
static DEFINE_MUTEX(wakeup_info_lock);

/* ---- framework state (sleep_ctrl) ---- */
struct sleep_ctrl_struct {
	bool enabled;
	unsigned int check_count;
};
static struct sleep_ctrl_struct sleep_ctrl = {
	.enabled = true,
	.check_count = 0,
};

/* ---- notifiers ---- */
BLOCKING_NOTIFIER_HEAD(sleep_notifier);
static struct notifier_block sleep_notifier_block;
static bool sleep_notifier_ready;

/*
 * disp_regs: read regmap register table and print
 * factory format: "##--%s.%s: 0x%08x"
 */
static int disp_regs(struct regmap *map, const char *name, u32 addr, u32 flag)
{
	unsigned int val;
	int ret;

	ret = regmap_read(map, addr, &val);
	if (ret)
		return ret;
	pr_info("  ##--%s.%s: 0x%08x", name, name, val);
	return 0;
}

/*
 * ap_sleep_condition_check - factory recon (0xffffff8008443cd0).
 * Iterates condition entries, resolves syscon regmaps, dumps registers.
 * Returns 0 = ok, -EINVAL = parameter error.
 */
int ap_sleep_condition_check(void *ctx, struct sleep_cond_ctx *conds)
{
	struct sleep_cond_entry *e;
	int i;

	if (!ctx || !conds) {
		pr_err("%s: Parameter is error", "state-check");
		return -EINVAL;
	}

	pr_info("###--POWER DOMAIN STATE");

	e = conds->head;
	for (i = 0; i < conds->count; i++, e++) {
		struct regmap *map;
		int ret;

		map = syscon_regmap_lookup_by_phandle(conds->np,
						      e->syscon_prop);
		if (IS_ERR(map)) {
			pr_info("  ##--Get %s regmap error", e->syscon_prop);
			continue;
		}
		if (!map) {
			pr_err("  ##--Register table is error");
			continue;
		}
		if (!e->name)
			continue;
		if (e->flag == 0 || !e->reg_addr) {
			pr_err("  ##--%s: 0x%08x", e->name, e->reg_addr);
			continue;
		}
		ret = disp_regs(map, e->name, e->reg_addr, e->flag);
		if (ret)
			pr_err("  ##--Display %s error", e->name);
	}
	return 0;
}
EXPORT_SYMBOL_GPL(ap_sleep_condition_check);

/* ---- wakeup_info registry API ---- */
struct wakeup_info *wakeup_info_register(const char *name, struct device *dev)
{
	struct wakeup_info *info;

	info = kzalloc(sizeof(*info), GFP_KERNEL);
	if (!info)
		return NULL;
	info->name = name;
	info->dev = dev;
	mutex_lock(&wakeup_info_lock);
	list_add_tail(&info->node, &wakeup_info_list);
	mutex_unlock(&wakeup_info_lock);
	pr_debug("sprd_debuglog: wakeup_info_register %s\n", name);
	return info;
}

void wakeup_info_unregister(struct wakeup_info *info)
{
	if (!info)
		return;
	mutex_lock(&wakeup_info_lock);
	list_del(&info->node);
	mutex_unlock(&wakeup_info_lock);
	kfree(info);
	pr_debug("sprd_debuglog: wakeup_info_unregister %s\n",
		 info->name ? info->name : "(null)");
}

/* ---- suspend path dump ---- */
static void sleep_dump_wakeup_infos(void)
{
	struct wakeup_info *info;

	mutex_lock(&wakeup_info_lock);
	list_for_each_entry(info, &wakeup_info_list, node)
		pr_info("  ##--wakeup_info: %s\n",
			info->name ? info->name : "(null)");
	mutex_unlock(&wakeup_info_lock);
}

static int sleep_pm_notify(struct notifier_block *nb, unsigned long mode,
			   void *_unused)
{
	switch (mode) {
	case PM_SUSPEND_PREPARE:
		if (!sleep_ctrl.enabled)
			break;
		sleep_ctrl.check_count++;
		pr_info("###--SLEEP STATE CHECK #%u\n", sleep_ctrl.check_count);
		sleep_dump_wakeup_infos();
		blocking_notifier_call_chain(&sleep_notifier, mode, NULL);
		break;
	case PM_POST_SUSPEND:
		blocking_notifier_call_chain(&sleep_notifier, mode, NULL);
		break;
	default:
		break;
	}
	return 0;
}

/* ---- sysfs: /sys/kernel/sleep_ctrl ---- */
static ssize_t sleep_ctrl_show(struct kobject *kobj, struct kobj_attribute *attr,
			       char *buf)
{
	return scnprintf(buf, PAGE_SIZE, "enabled=%d checks=%u\n",
			 sleep_ctrl.enabled, sleep_ctrl.check_count);
}

static ssize_t sleep_ctrl_store(struct kobject *kobj,
				struct kobj_attribute *attr,
				const char *buf, size_t len)
{
	unsigned int v;

	if (kstrtouint(buf, 0, &v) == 0)
		sleep_ctrl.enabled = !!v;
	return len;
}

static struct kobj_attribute sleep_ctrl_attr =
	__ATTR(sleep_ctrl, 0644, sleep_ctrl_show, sleep_ctrl_store);
static struct kobject *sleep_ctrl_kobj;

/* ---- platform driver shell (factory sprd_debuglog_driver) ---- */
static const struct of_device_id sprd_debuglog_of_match[] = {
	{ .compatible = "sprd,sprd-debuglog" },
	{ }
};
MODULE_DEVICE_TABLE(of, sprd_debuglog_of_match);

static int sprd_debuglog_probe(struct platform_device *pdev)
{
	dev_info(&pdev->dev, "sprd_debuglog probe\n");
	return 0;
}

static struct platform_driver sprd_debuglog_driver = {
	.driver = {
		.name		= "sprd-debuglog",
		.of_match_table	= sprd_debuglog_of_match,
	},
	.probe = sprd_debuglog_probe,
};

static int __init sprd_debuglog_driver_init(void)
{
	int ret;

	sleep_notifier_block.notifier_call = sleep_pm_notify;
	ret = register_pm_notifier(&sleep_notifier_block);
	if (ret) {
		pr_err("sprd_debuglog: register_pm_notifier failed %d\n", ret);
		return ret;
	}
	sleep_notifier_ready = true;

	sleep_ctrl_kobj = kobject_create_and_add("sleep_ctrl", kernel_kobj);
	if (sleep_ctrl_kobj) {
		ret = sysfs_create_file(sleep_ctrl_kobj, &sleep_ctrl_attr.attr);
		if (ret)
			pr_warn("sprd_debuglog: sysfs create failed\n");
	}

	ret = platform_driver_register(&sprd_debuglog_driver);
	if (ret)
		pr_warn("sprd_debuglog: platform_driver_register ret=%d\n", ret);

	pr_info("sprd_debuglog: init done\n");
	return 0;
}

static void __exit sprd_debuglog_driver_exit(void)
{
	platform_driver_unregister(&sprd_debuglog_driver);
	if (sleep_ctrl_kobj) {
		sysfs_remove_file(sleep_ctrl_kobj, &sleep_ctrl_attr.attr);
		kobject_put(sleep_ctrl_kobj);
		sleep_ctrl_kobj = NULL;
	}
	if (sleep_notifier_ready) {
		unregister_pm_notifier(&sleep_notifier_block);
		sleep_notifier_ready = false;
	}
	pr_info("sprd_debuglog: exit\n");
}

module_init(sprd_debuglog_driver_init);
module_exit(sprd_debuglog_driver_exit);

MODULE_AUTHOR("W527 r38 port");
MODULE_DESCRIPTION("W527 sleep monitor / power-state debug framework");
MODULE_LICENSE("GPL");
