# -*- coding: utf-8 -*-
"""W527 驱动移植脚本 v2（真幂等）：qmc6308 磁力计 + mir3da G-sensor + eta6947 充电 IC
tarball 内含 pristine 源码（qmc6308.h 已预修 QMC_MISCDEV_NAME），本脚本只做文本补丁。
在内核树根目录运行: python3 port_drivers.py .
v2 修复:
  - qmc6308.c 增补 #include "qmc6308.h"（run17 失败根因：宏全未定义）
  - i2c-dev.h 注释补丁加幂等护栏（run17 双重补丁产生嵌套注释语法错）
  - mir3da_cust.c 拆除无保护的 #include <linux/earlysuspend.h>（树无 EARLYSUSPEND，
    函数体/成员/注册点本就有 #ifdef CONFIG_HAS_EARLYSUSPEND 保护，仅 include 裸奔）
"""
import os, sys, io

TREE = sys.argv[1] if len(sys.argv) > 1 else '.'
IM = os.path.join(TREE, 'drivers/input/misc')

def read(p):
    with io.open(p, encoding='utf-8', errors='replace') as f:
        return f.read()

def write(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='\n') as f:
        f.write(s)

# ---------- 1. qmc6308.c ----------
p = os.path.join(IM, 'qmc6308/qmc6308.c')
s = read(p)
# 1a. 包含本地头文件（寄存器/ioctl 宏与 struct qmc6308_platform_data 全在里面）
if '#include "qmc6308.h"' not in s:
    s = s.replace('//#include <linux/i2c/qmc6308.h>',
                  '//#include <linux/i2c/qmc6308.h>\n#include "qmc6308.h" /* W527: local copy of QST header */', 1)
    print('[patch] qmc6308.c: + #include "qmc6308.h"')
# 1b. 注释掉用户态头（幂等：已有注释形式则跳过）
if '/* #include <linux/i2c-dev.h>' not in s and '// #include <linux/i2c-dev.h>' not in s \
   and '//#include <linux/i2c-dev.h>' not in s and '#include <linux/i2c-dev.h>' in s:
    s = s.replace('#include <linux/i2c-dev.h>',
                  '/* #include <linux/i2c-dev.h> removed: userspace header */', 1)
    print('[patch] qmc6308.c: drop userspace i2c-dev.h include')
# 1c. of_match 补 W527 dtb compatible（dtb 实际字符串 qmc,qmc6308）
if '"qmc,qmc6308"' not in s:
    s = s.replace('{ .compatible = "qst,qmc6308", },',
                  '{ .compatible = "qst,qmc6308", },\n\t{ .compatible = "qmc,qmc6308", }, /* W527 dtb */', 1)
    print('[patch] qmc6308.c: of_match += qmc,qmc6308')
write(p, s)

# ---------- 2. qmc6308.h 自检（防打包错版本） ----------
p = os.path.join(IM, 'qmc6308/qmc6308.h')
s = read(p)
missing = [m for m in ('OUT_X_REG', 'CTL_REG_ONE', 'STA_REG_ONE', 'QMC6308_CHIP_ID',
                       'QMC_I2C_NAME', 'QMC6308_IOCTL_MSENSOR_ENABLE') if m not in s]
if missing:
    print('[FATAL] qmc6308.h 打包版本错误，缺宏:', missing)
    sys.exit(1)
if '"qmcX983"' in s and '"qmc6308"' in s:
    print('[ok] qmc6308.h: QMC_MISCDEV_NAME=qmc6308 预修已生效')
print('[check] qmc6308.h 宏齐全')

# ---------- 3. mir3da_cust.c ----------
p = os.path.join(IM, 'mir3da/mir3da_cust.c')
s = read(p)
# 3a. earlysuspend.h 裸 include 拆除（幂等）
if '/* #include <linux/earlysuspend.h>' not in s and '#include <linux/earlysuspend.h>' in s:
    s = s.replace('#include <linux/earlysuspend.h>',
                  '/* #include <linux/earlysuspend.h> removed: not in 4.14 mainline tree */', 1)
    print('[patch] mir3da_cust.c: drop earlysuspend.h include')
# 3b. of_match 补 W527 gsensor compatible（dtb 实际字符串 da,da217）
if '"da,da217"' not in s:
    s = s.replace('{ .compatible = "da,da213", },',
                  '{ .compatible = "da,da213", },\n\t{ .compatible = "da,da217", }, /* W527 gsensor */', 1)
    print('[patch] mir3da_cust.c: of_match += da,da217')
write(p, s)

# ---------- 4. input/misc Makefile 追加 ----------
p = os.path.join(IM, 'Makefile')
s = read(p)
add = []
if 'qmc6308/qmc6308.o' not in s:
    add.append('obj-$(CONFIG_SENSORS_QMC6308) += qmc6308/qmc6308.o')
# 组合对象必须挂在 misc 目录本身（mir3da/ 子目录无 Makefile，
# 写成 mir3da/mir3da.o 会让 kbuild 找子目录规则报 "No rule to make target"）
if 'obj-$(CONFIG_INPUT_MIR3DA) += mir3da.o' not in s:
    add.append('obj-$(CONFIG_INPUT_MIR3DA) += mir3da.o\nmir3da-y := mir3da/mir3da_core.o mir3da/mir3da_cust.o')
if add:
    s = s.rstrip('\n') + '\n# W527 drivers\n' + '\n'.join(add) + '\n'
    write(p, s)
    print('[patch] input/misc/Makefile: +', len(add), 'lines')

# ---------- 5. input/misc Kconfig 追加 ----------
p = os.path.join(IM, 'Kconfig')
s = read(p)
need = []
if 'config SENSORS_QMC6308' not in s:
    need.append('''config SENSORS_QMC6308
	tristate "QST QMC6308 magnetic sensor (W527)"
	depends on I2C=y
	default y
	help
	  QST QMC6308 3-axis magnetometer via misc device /dev/qmc6308.
''')
if 'config INPUT_MIR3DA' not in s:
    need.append('''config INPUT_MIR3DA
	tristate "MIR3DA/DA217 gsensor (W527)"
	depends on I2C=y
	default y
	help
	  Davicom mir3da series (DA217) 3-axis accelerometer,
	  misc device /dev/mir3da plus input events.
''')
if need:
    s = s.rstrip('\n') + '\n# W527 drivers\n' + '\n'.join(need) + '\n'
    write(p, s)
    print('[patch] input/misc/Kconfig: +', len(need), 'blocks')

# ---------- 6. eta6947（树内已有驱动，config 开关在 w527.config） ----------
print('PORT DONE')
