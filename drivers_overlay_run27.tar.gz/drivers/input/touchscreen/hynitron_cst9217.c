/*
 * Hynitron CST9217 Touchscreen Driver - W527 run#30
 *
 * 协议与 probe 时序完全对齐厂商树老 SDK (hynitron_core.c 定制版,
 * run#25/26 实测 9217 接受该协议, 8.7Hz 可跑):
 *
 *  1. 帧头 7 字节 @0xD000, buf[6]==0xAB 有效, buf[0]!=0xAB
 *  2. buf[5]==0x80 -> 纯 key 帧; 否则 cnt = buf[5]&0x7F
 *  3. cnt>1 时从 0xD007 二次读 (cnt-1)*5+1 字节, 数据落在 buf[5..]
 *     (老 SDK cst3xx_i2c_read_register: 寄存器地址占 buf 前 2 字节,
 *      数据从头覆写), 末字节 buf[5+(cnt-1)*5]==0xAB
 *  4. 点数据从 buf[0] 起每点连续 5 字节:
 *     byte0: id<<4 | state, state>>1==3 down / ==0 up
 *     byte1,2,3: x/y 各 12bit
 *  5. 每帧消费后 ACK: 向 0xD000 写 0xAB (3 字节事务 {D0,00,AB})
 *     ACK 在解析上报之前 (老 SDK 时序)
 *  6. 严禁一次读超过 7 字节的帧头 -- run#28/29 一次硬读 27 字节
 *     越界把固件状态机搞乱, ACK 后中断线不放 = 死触屏根因
 *
 *  probe 时序复刻老 SDK: 挂中断 -> disable -> hw_reset(线回干净
 *  高电平) -> 0xD109(normal) -> drain 首帧 -> enable
 *  (run#28/29 在芯片已拉低报首帧之后才挂 FALLING 中断 = 线出生即低死锁)
 *
 *  开机 probe 不自动的修复: gpio_request 的 -EPROBE_DEFER 向上
 *  传递让 i2c core 稍后重试 (run#28/29 静默吞掉 -> irq=0 ->
 *  request_irq(0) 硬失败, 永不重试, 需手动 bind)
 */

#include <linux/module.h>
#include <linux/i2c.h>
#include <linux/input.h>
#include <linux/input/mt.h>
#include <linux/interrupt.h>
#include <linux/delay.h>
#include <linux/gpio.h>
#include <linux/of_gpio.h>
#include <linux/regulator/consumer.h>
#include <linux/slab.h>
#include <linux/mutex.h>
#include <linux/pinctrl/consumer.h>

#define HYN_REG_BASE            0xD000
#define HYN_CMD_NORMAL          0xD109

#define HYN_MAX_POINTS          5
#define HYN_STATE_DOWN          0x03    /* (byte0 & 0x0F) >> 1 */

#define HYN_BUF_LEN             32      /* 5 + (5-1)*5 + margin = 25+ */

/* #define DEBUG_RAW_DATA */

struct cst9217_ts_data {
    struct i2c_client *client;
    struct input_dev *input_dev;
    int irq_gpio;
    int reset_gpio;
    int irq;
    u32 abs_x_max;
    u32 abs_y_max;
    bool x_reverse;
    bool y_reverse;
    bool suspended;
    struct regulator *vdd;
    struct mutex mutex;
};

#define HYN_INFO(fmt, ...) pr_info("[HYN_TS] " fmt, ##__VA_ARGS__)
#define HYN_ERR(fmt, ...) pr_err("[HYN_TS] Error: " fmt, ##__VA_ARGS__)

static int hyn_i2c_read(struct i2c_client *client, u16 reg, u8 *data, int len)
{
    struct i2c_msg msgs[2];
    u8 reg_buf[2];
    int ret;

    reg_buf[0] = (reg >> 8) & 0xFF;
    reg_buf[1] = reg & 0xFF;

    msgs[0].addr = client->addr;
    msgs[0].flags = 0;
    msgs[0].len = 2;
    msgs[0].buf = reg_buf;

    msgs[1].addr = client->addr;
    msgs[1].flags = I2C_M_RD;
    msgs[1].len = len;
    msgs[1].buf = data;

    ret = i2c_transfer(client->adapter, msgs, 2);
    return (ret == 2) ? 0 : -EIO;
}

static int hyn_i2c_write(struct i2c_client *client, u16 reg, u8 *data, int len)
{
    u8 buf[8];
    int ret;
    struct i2c_msg msg;

    if (len > 4)
        return -EINVAL;

    buf[0] = (reg >> 8) & 0xFF;
    buf[1] = reg & 0xFF;
    if (len > 0 && data)
        memcpy(&buf[2], data, len);

    msg.addr = client->addr;
    msg.flags = 0;
    msg.len = len + 2;
    msg.buf = buf;

    ret = i2c_transfer(client->adapter, &msg, 1);
    return (ret == 1) ? 0 : -EIO;
}

/* 每帧消费完成后的 ACK: 等价老 SDK i2c_master_send({0xD0,0x00,0xAB},3) */
static int hyn_send_ack(struct cst9217_ts_data *ts)
{
    u8 ack = 0xAB;
    return hyn_i2c_write(ts->client, HYN_REG_BASE, &ack, 1);
}

static void cst9217_release_all(struct cst9217_ts_data *ts)
{
    int i;
    for (i = 0; i < HYN_MAX_POINTS; i++) {
        input_mt_slot(ts->input_dev, i);
        input_mt_report_slot_state(ts->input_dev, MT_TOOL_FINGER, false);
    }
    input_mt_sync_frame(ts->input_dev);
    input_report_key(ts->input_dev, BTN_TOUCH, 0);
    input_sync(ts->input_dev);
}

static void cst9217_report_touch(struct cst9217_ts_data *ts)
{
    u8 buf[HYN_BUF_LEN] = {0};
    int ret, i;
    int cnt;
    unsigned long active_ids = 0;
    bool any_down = false;

    mutex_lock(&ts->mutex);

    /* 帧头只读 7 字节 —— 老 SDK 协议铁律 */
    ret = hyn_i2c_read(ts->client, HYN_REG_BASE, buf, 7);
    if (ret < 0) {
        HYN_ERR("i2c read head failed\n");
        hyn_send_ack(ts);
        goto out_unlock;
    }

#ifdef DEBUG_RAW_DATA
    print_hex_dump(KERN_INFO, "[HYN_RAW] ", DUMP_PREFIX_NONE, 16, 1,
                   buf, 7, false);
#endif

    /* 无效帧: ACK + 清槽 (老 SDK OUT_PROCESS 同款) */
    if (buf[6] != 0xAB || buf[0] == 0xAB) {
        hyn_send_ack(ts);
        cst9217_release_all(ts);
        goto out_unlock;
    }

    /* 纯 key 帧: W527 无实体触摸 key, ACK 后清槽 */
    if (buf[5] == 0x80) {
        hyn_send_ack(ts);
        cst9217_release_all(ts);
        goto out_unlock;
    }

    cnt = buf[5] & 0x7F;
    if (cnt > HYN_MAX_POINTS) {
        hyn_send_ack(ts);
        goto out_unlock;
    }
    if (cnt == 0) {
        hyn_send_ack(ts);
        cst9217_release_all(ts);
        goto out_unlock;
    }

    /* 多点: 二次读 0xD007 起 (cnt-1)*5+1 字节, 数据落 buf[5..],
     * 末尾字节必须是 0xAB */
    if (cnt > 1) {
        int len2 = (cnt - 1) * 5 + 1;
        ret = hyn_i2c_read(ts->client, 0xD007, &buf[5], len2);
        if (ret < 0) {
            HYN_ERR("i2c read points failed\n");
            hyn_send_ack(ts);
            goto out_unlock;
        }
        if (buf[5 + (cnt - 1) * 5] != 0xAB) {
            HYN_ERR("frame tail != 0xAB (cnt=%d)\n", cnt);
            hyn_send_ack(ts);
            goto out_unlock;
        }
    }

    /* 老 SDK 时序: 先 ACK 后解析上报 */
    hyn_send_ack(ts);

    for (i = 0; i < cnt; i++) {
        int idx = i * 5;    /* 点数据从 buf[0] 起连续 5 字节/点 */
        int id, sw;
        unsigned int x, y;

        id = (buf[idx] >> 4) & 0x0F;
        sw = (buf[idx] & 0x0F) >> 1;
        x = ((unsigned int)buf[idx + 1] << 4) | ((buf[idx + 3] >> 4) & 0x0F);
        y = ((unsigned int)buf[idx + 2] << 4) | (buf[idx + 3] & 0x0F);

        if (ts->x_reverse)
            x = ts->abs_x_max - x;
        if (ts->y_reverse)
            y = ts->abs_y_max - y;

        if (id >= HYN_MAX_POINTS) {
            HYN_INFO("bad point id %d, skip\n", id);
            continue;
        }

        if (sw == HYN_STATE_DOWN) {
            input_mt_slot(ts->input_dev, id);
            input_mt_report_slot_state(ts->input_dev, MT_TOOL_FINGER, true);
            input_report_abs(ts->input_dev, ABS_MT_POSITION_X, x);
            input_report_abs(ts->input_dev, ABS_MT_POSITION_Y, y);
            __set_bit(id, &active_ids);
            any_down = true;
        }
        /* sw==0 (up): protocol B 由下方 slot state=false 处理 */
    }

    for (i = 0; i < HYN_MAX_POINTS; i++) {
        if (!test_bit(i, &active_ids)) {
            input_mt_slot(ts->input_dev, i);
            input_mt_report_slot_state(ts->input_dev, MT_TOOL_FINGER, false);
        }
    }
    input_mt_sync_frame(ts->input_dev);
    input_report_key(ts->input_dev, BTN_TOUCH, any_down ? 1 : 0);
    input_sync(ts->input_dev);

out_unlock:
    mutex_unlock(&ts->mutex);
}

static irqreturn_t cst9217_irq_handler(int irq, void *dev_id)
{
    struct cst9217_ts_data *ts = dev_id;
    int guard = 0;

    /* 至少消费一帧; 线保持低 (电平保持固件模式) 则继续 drain */
    do {
        cst9217_report_touch(ts);
    } while (gpio_is_valid(ts->irq_gpio) &&
             !gpio_get_value(ts->irq_gpio) && ++guard < 10);
    return IRQ_HANDLED;
}

static void cst9217_hw_reset(struct cst9217_ts_data *ts)
{
    if (gpio_is_valid(ts->reset_gpio)) {
        gpio_direction_output(ts->reset_gpio, 0);
        msleep(10);
        gpio_set_value(ts->reset_gpio, 1);
        msleep(50);
    }
}

static int cst9217_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
    struct device_node *np = client->dev.of_node;
    struct cst9217_ts_data *ts;
    u32 coords[4];
    u32 gpios[3];
    int ret;
    int irq_line;

    struct pinctrl *p = devm_pinctrl_get(&client->dev);
    if (!IS_ERR(p)) {
        struct pinctrl_state *s = pinctrl_lookup_state(p, "hyn_irq_gpio");
        if (!IS_ERR(s)) {
            pinctrl_select_state(p, s);
            dev_info(&client->dev, "Set pinctrl to hyn_irq_gpio\n");
        }
    }

    HYN_INFO("Probe Start (run#30, old-SDK protocol)\n");

    ts = devm_kzalloc(&client->dev, sizeof(*ts), GFP_KERNEL);
    if (!ts) return -ENOMEM;

    ts->client = client;
    i2c_set_clientdata(client, ts);
    mutex_init(&ts->mutex);

    ts->vdd = regulator_get(NULL, "vddsdcore");
    if (!IS_ERR(ts->vdd)) {
        ret = regulator_set_voltage(ts->vdd, 2800000, 3000000);
        if (ret) HYN_ERR("Failed to set regulator voltage\n");
        ret = regulator_enable(ts->vdd);
        if (ret) HYN_ERR("Failed to enable regulator\n");
        msleep(20);
    }

    if (of_property_read_u32_array(np, "reset-gpio", gpios, 3) == 0)
        ts->reset_gpio = gpios[1];
    else
        ts->reset_gpio = -1;

    if (of_property_read_u32_array(np, "irq-gpio", gpios, 3) == 0)
        ts->irq_gpio = gpios[1];
    else
        ts->irq_gpio = -1;

    /* run#30: -EPROBE_DEFER 必须上抛, 否则开机早期 GPIO 控制器
     * 未就绪时 probe 永久失败 (run#28/29 需手动 bind 的根因) */
    if (gpio_is_valid(ts->reset_gpio)) {
        ret = gpio_request(ts->reset_gpio, "hyn_rst");
        if (ret == -EPROBE_DEFER) return ret;
        if (ret == 0)
            cst9217_hw_reset(ts);
        else
            ts->reset_gpio = -1;
    }

    {
        u8 dummy[4];
        if (hyn_i2c_read(client, HYN_REG_BASE, dummy, 4) < 0) {
            HYN_ERR("I2C comm failed, retry after reset\n");
            if (gpio_is_valid(ts->reset_gpio))
                cst9217_hw_reset(ts);
            msleep(100);
        }
    }

    if (of_property_read_u32_array(np, "display-coords", coords, 4) == 0) {
        ts->abs_x_max = coords[2];
        ts->abs_y_max = coords[3];
    } else if (of_property_read_u32_array(np, "display-coords", coords, 2) == 0) {
        ts->abs_x_max = coords[0];
        ts->abs_y_max = coords[1];
    } else {
        ts->abs_x_max = 410;
        ts->abs_y_max = 502;
    }

    {
        u32 rev;
        if (of_property_read_u32(np, "posx-reverse", &rev) == 0)
            ts->x_reverse = (rev != 0);
        if (of_property_read_u32(np, "posy-reverse", &rev) == 0)
            ts->y_reverse = (rev != 0);
        HYN_INFO("coords %ux%u, x_reverse=%d y_reverse=%d\n",
                 ts->abs_x_max, ts->abs_y_max,
                 ts->x_reverse, ts->y_reverse);
    }

    ts->input_dev = devm_input_allocate_device(&client->dev);
    if (!ts->input_dev) return -ENOMEM;

    ts->input_dev->name = "Hynitron cst9217 Touchscreen";
    ts->input_dev->id.bustype = BUS_I2C;

    input_set_abs_params(ts->input_dev, ABS_MT_POSITION_X, 0, ts->abs_x_max, 0, 0);
    input_set_abs_params(ts->input_dev, ABS_MT_POSITION_Y, 0, ts->abs_y_max, 0, 0);
    input_set_abs_params(ts->input_dev, ABS_X, 0, ts->abs_x_max, 0, 0);
    input_set_abs_params(ts->input_dev, ABS_Y, 0, ts->abs_y_max, 0, 0);
    input_set_abs_params(ts->input_dev, ABS_MT_TRACKING_ID, 0, 65535, 0, 0);
    input_set_abs_params(ts->input_dev, ABS_MT_SLOT, 0, HYN_MAX_POINTS - 1, 0, 0);

    input_mt_init_slots(ts->input_dev, HYN_MAX_POINTS, INPUT_MT_DIRECT);
    input_set_capability(ts->input_dev, EV_KEY, BTN_TOUCH);

    ret = input_register_device(ts->input_dev);
    if (ret) return ret;

    if (gpio_is_valid(ts->irq_gpio)) {
        ret = gpio_request(ts->irq_gpio, "hyn_irq");
        if (ret == -EPROBE_DEFER) return ret;
        if (ret == 0) {
            gpio_direction_input(ts->irq_gpio);
            ts->irq = gpio_to_irq(ts->irq_gpio);
        } else {
            ts->irq_gpio = -1;
        }
    }
    if (ts->irq <= 0 && gpio_is_valid(ts->irq_gpio))
        ts->irq = gpio_to_irq(ts->irq_gpio);
    if (ts->irq <= 0 && client->irq > 0)
        ts->irq = client->irq;
    if (ts->irq <= 0) {
        HYN_ERR("no valid irq\n");
        return -EINVAL;
    }

    /* 双沿: 老 SDK 用 RISING (电平保持模式下 "ACK 回高沿" 驱动
     * 主循环); FALLING 兜底捕获 "帧 ready 拉低" 事件 */
    ret = devm_request_threaded_irq(&client->dev, ts->irq, NULL,
                                    cst9217_irq_handler,
                                    IRQF_ONESHOT |
                                    IRQF_TRIGGER_RISING | IRQF_TRIGGER_FALLING,
                                    "hyn_ts", ts);
    if (ret) {
        HYN_ERR("Failed to request IRQ %d\n", ts->irq);
        return ret;
    }

    /* ===== 复刻老 SDK 关键时序: 挂中断后先禁 -> 复位(线回干净
     * 高电平) -> 初始化命令 -> 消费首帧 -> 才使能中断 ===== */
    disable_irq(ts->irq);

    cst9217_hw_reset(ts);
    msleep(60);     /* 老 SDK probe 同款 mdelay(60) */

    {
        u8 cmd2[2] = {0xD1, 0x09};
        struct i2c_msg m = { .addr = client->addr, .flags = 0,
                             .len = 2, .buf = cmd2 };
        ret = i2c_transfer(client->adapter, &m, 1);
        HYN_INFO("Init cmd 0xD109 %s\n", ret == 1 ? "sent" : "FAILED");
    }
    msleep(20);

    /* 消费复位后芯片报出的首帧, 把中断线放回高电平 */
    {
        int guard = 0;
        do {
            cst9217_report_touch(ts);
        } while (gpio_is_valid(ts->irq_gpio) &&
                 !gpio_get_value(ts->irq_gpio) && ++guard < 10);
    }
    irq_line = gpio_is_valid(ts->irq_gpio) ? gpio_get_value(ts->irq_gpio) : -1;
    HYN_INFO("irq line after drain: %d\n", irq_line);

    if (irq_line == 0) {
        /* 线仍卡低: 最后兜底再复位一次 (复位中线必回高) */
        HYN_ERR("irq line stuck low, emergency reset\n");
        cst9217_hw_reset(ts);
        msleep(80);
        {
            int guard = 0;
            do {
                cst9217_report_touch(ts);
            } while (gpio_is_valid(ts->irq_gpio) &&
                     !gpio_get_value(ts->irq_gpio) && ++guard < 10);
        }
        irq_line = gpio_is_valid(ts->irq_gpio) ? gpio_get_value(ts->irq_gpio) : -1;
        HYN_INFO("irq line after emergency reset: %d\n", irq_line);
    }

    enable_irq(ts->irq);

    HYN_INFO("Probe success! IRQ: %d (RISING|FALLING), line=%d\n",
             ts->irq, irq_line);
    return 0;
}

static int cst9217_remove(struct i2c_client *client)
{
    struct cst9217_ts_data *ts = i2c_get_clientdata(client);
    if (gpio_is_valid(ts->reset_gpio)) gpio_free(ts->reset_gpio);
    if (gpio_is_valid(ts->irq_gpio)) gpio_free(ts->irq_gpio);
    if (!IS_ERR(ts->vdd)) regulator_put(ts->vdd);
    return 0;
}

static int cst9217_suspend(struct device *dev)
{
    struct cst9217_ts_data *ts = i2c_get_clientdata(to_i2c_client(dev));

    if (ts->irq > 0)
        disable_irq(ts->irq);
    ts->suspended = true;
    mutex_lock(&ts->mutex);
    cst9217_release_all(ts);
    mutex_unlock(&ts->mutex);
    return 0;
}

static int cst9217_resume(struct device *dev)
{
    struct cst9217_ts_data *ts = i2c_get_clientdata(to_i2c_client(dev));

    if (gpio_is_valid(ts->reset_gpio))
        cst9217_hw_reset(ts);
    msleep(20);
    {
        u8 cmd2[2] = {0xD1, 0x09};
        struct i2c_msg m = { .addr = ts->client->addr, .flags = 0,
                             .len = 2, .buf = cmd2 };
        i2c_transfer(ts->client->adapter, &m, 1);
    }
    msleep(20);
    ts->suspended = false;
    if (ts->irq > 0)
        enable_irq(ts->irq);
    HYN_INFO("resumed\n");
    return 0;
}

static const struct dev_pm_ops cst9217_pm_ops = {
    .suspend = cst9217_suspend,
    .resume  = cst9217_resume,
};

static const struct of_device_id cst9217_match[] = {
    { .compatible = "hynitron,hyn_ts" },
    { .compatible = "hyn,92xx" },
    { }
};
static const struct i2c_device_id cst9217_id[] = {
    { "hyn_ts", 0 },
    { "92xx", 0 },
    { }
};
MODULE_DEVICE_TABLE(of, cst9217_match);

static struct i2c_driver cst9217_driver = {
    .driver = {
        .name = "hynitron_ts",
        .of_match_table = cst9217_match,
        .pm = &cst9217_pm_ops,
    },
    .probe = cst9217_probe,
    .remove = cst9217_remove,
    .id_table = cst9217_id,
};

module_i2c_driver(cst9217_driver);
MODULE_LICENSE("GPL");
