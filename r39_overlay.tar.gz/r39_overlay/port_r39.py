#!/usr/bin/env python3
"""r39 port script: r36's little brother - mas fingerprint + hxd019 IR into
ZDC tree. NO sleep debuglog (r36 did not have it; prime jank suspect).
Run from CI `source` dir (kernel tree root). Idempotent."""
import os, sys, re

def must(cond, msg):
    if not cond:
        print("FAIL:", msg); sys.exit(1)
    print("OK:", msg)

# ---------- 1. mas fingerprint ----------
fp = "drivers/input/fingerprint"
os.makedirs(fp, exist_ok=True)

for src in ("../r39_overlay/mas/mas_core.c", "r39_overlay/mas/mas_core.c"):
    if os.path.exists(src):
        data = open(src, encoding="utf-8").read()
        open(os.path.join(fp, "mas_core.c"), "w", encoding="utf-8", newline="\n").write(data)
        break
else:
    must(False, "mas_core.c source not found")

open(os.path.join(fp, "Kconfig"), "w", newline="\n").write(
"""menuconfig INPUT_FINGERPRINT
	bool "Fingerprint support"
	depends on INPUT
	default y
	help
	  Say Y here to enable fingerprint sensor drivers.

if INPUT_FINGERPRINT

config MICROARRAY_FINGERPRINT
	tristate "Microarray SPI fingerprint sensor (W527 mas factory-spec)"
	depends on SPI
	default y
	help
	  Microarray SPI fingerprint driver, W527 factory-spec port.
	  DTB binding: compatible "microarray,mafp" under spi@70a00000.
	  Chardev /dev/madev0, ioctl magic 'M'.

endif
""")

open(os.path.join(fp, "Makefile"), "w", newline="\n").write(
"# W527 r39: Microarray SPI fingerprint (factory-spec port)\n"
"obj-$(CONFIG_MICROARRAY_FINGERPRINT) += mas_core.o\n")

# patch drivers/input/Kconfig
p = "drivers/input/Kconfig"
s = open(p, encoding="utf-8").read()
line = 'source "drivers/input/fingerprint/Kconfig"'
if line not in s:
    if 'touchscreen/Kconfig' in s:
        s = re.sub(r'(source "drivers/input/touchscreen/Kconfig")',
                   r'\1\n' + line, s, count=1)
    else:
        idx = s.rfind("endmenu")
        s = s[:idx] + line + "\n" + s[idx:]
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must(line in open(p).read(), "drivers/input/Kconfig has fingerprint source")

# patch drivers/input/Makefile
p = "drivers/input/Makefile"
s = open(p, encoding="utf-8").read()
objline = "obj-$(CONFIG_MICROARRAY_FINGERPRINT) += fingerprint/"
if objline not in s:
    s = s.rstrip("\n") + "\n" + objline + "\n"
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must(objline in open(p).read(), "drivers/input/Makefile has fingerprint obj")

# ---------- 2. hxd019 IR (ctrl driver; manual-cdev r38d proven build) ----------
sd = "drivers/misc"
data = None
for src in ("../r39_overlay/hxd/hxd019_ir.c", "r39_overlay/hxd/hxd019_ir.c"):
    if os.path.exists(src):
        data = open(src, encoding="utf-8").read()
        break
must(data is not None, "hxd019_ir.c source not found")
open(os.path.join(sd, "hxd019_ir.c"), "w", encoding="utf-8", newline="\n").write(data)

p = "drivers/misc/Kconfig"
s = open(p, encoding="utf-8").read()
if "HXD019_IR" not in s:
    block = (
"config HXD019_IR\n"
"\tbool \"HXD019 IR transceiver ctrl driver (W527)\"\n"
"\tdepends on GPIOLIB && PINCTRL\n"
"\tdefault y\n"
"\thelp\n"
"\t  HXD019 3-wire IR transceiver controller, W527 factory-spec port.\n"
"\t  DTB binding: compatible \"hxdkj,hxd019\". /dev/ctrl + /sys/class/ctrl.\n"
"\n")
    idx = s.find("endmenu")
    if idx >= 0:
        s = s[:idx] + block + s[idx:]
    else:
        s = s.rstrip("\n") + "\n\n" + block
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must("HXD019_IR" in open(p).read(), "drivers/misc/Kconfig has HXD019_IR")

p = "drivers/misc/Makefile"
s = open(p, encoding="utf-8").read()
if "hxd019_ir" not in s:
    s = s.rstrip("\n") + "\nobj-$(CONFIG_HXD019_IR) += hxd019_ir.o\n"
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must("hxd019_ir" in open(p).read(), "drivers/misc/Makefile has hxd019_ir")

# ---------- 3. config ----------
cfg = None
for c in ("../w527.config", "w527.config"):
    if os.path.exists(c):
        cfg = c; break
must(cfg is not None, "config file located: " + str(cfg))
s = open(cfg, encoding="utf-8").read()
for k in ("CONFIG_MICROARRAY_FINGERPRINT=y", "CONFIG_INPUT_FINGERPRINT=y",
          "CONFIG_HXD019_IR=y"):
    if k not in s:
        s = s.rstrip("\n") + "\n" + k + "\n"
open(cfg, "w", encoding="utf-8", newline="\n").write(s)
s2 = open(cfg).read()
for k in ("CONFIG_MICROARRAY_FINGERPRINT=y", "CONFIG_INPUT_FINGERPRINT=y",
          "CONFIG_HXD019_IR=y"):
    must(k in s2, "config has " + k)

# explicit: SPRD_DEBUGLOG must NOT be enabled in r39
s2 = open(cfg).read()
if "CONFIG_SPRD_DEBUGLOG" in s2:
    s2 = s2.replace("CONFIG_SPRD_DEBUGLOG=y", "# CONFIG_SPRD_DEBUGLOG is not set")
    open(cfg, "w", encoding="utf-8", newline="\n").write(s2)
must("CONFIG_SPRD_DEBUGLOG=y" not in open(cfg).read(),
     "config has NO SPRD_DEBUGLOG (r36 parity)")

print("\nr39 port complete (r36 + mas + hxd019, no debuglog).")
