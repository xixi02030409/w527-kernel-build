#!/usr/bin/env python3
"""r38 port script: integrate mas fingerprint + sleep debuglog into ZDC tree.
Run from CI `source` dir (kernel tree root). Idempotent."""
import os, sys, re

def must(cond, msg):
    if not cond:
        print("FAIL:", msg); sys.exit(1)
    print("OK:", msg)

# ---------- 1. mas fingerprint ----------
fp = "drivers/input/fingerprint"
os.makedirs(fp, exist_ok=True)

# copy mas_core.c from package (workflow unpacks overlay at repo root, package sits beside source)
for src in ("../r38_overlay/mas/mas_core.c", "r38_overlay/mas/mas_core.c"):
    if os.path.exists(src):
        data = open(src, encoding="utf-8").read()
        open(os.path.join(fp, "mas_core.c"), "w", encoding="utf-8", newline="\n").write(data)
        break
else:
    must(False, "mas_core.c source not found")

open(os.path.join(fp, "Kconfig"), "w", newline="\n").write(
"""menuconfig INPUT_FINGERPRINT
	bool "Fingerprint support"
	depends on INPUT
	default y
	help
	  Say Y here to enable fingerprint sensor drivers.

if INPUT_FINGERPRINT

config MICROARRAY_FINGERPRINT
	tristate "Microarray SPI fingerprint sensor (W527 mas factory-spec)"
	depends on SPI
	default y
	help
	  Microarray SPI fingerprint driver, W527 factory-spec port.
	  DTB binding: compatible "microarray,mafp" under spi@70a00000.
	  Chardev /dev/madev0, ioctl magic 'M'.

endif
""")

open(os.path.join(fp, "Makefile"), "w", newline="\n").write(
"# W527 r38: Microarray SPI fingerprint (factory-spec port)\n"
"obj-$(CONFIG_MICROARRAY_FINGERPRINT) += mas_core.o\n")

# patch drivers/input/Kconfig
p = "drivers/input/Kconfig"
s = open(p, encoding="utf-8").read()
line = 'source "drivers/input/fingerprint/Kconfig"'
if line not in s:
    if 'touchscreen/Kconfig' in s:
        s = re.sub(r'(source "drivers/input/touchscreen/Kconfig")',
                   r'\1\n' + line, s, count=1)
    else:
        # fallback: before trailing endmenu
        idx = s.rfind("endmenu")
        s = s[:idx] + line + "\n" + s[idx:]
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must(line in open(p).read(), "drivers/input/Kconfig has fingerprint source")

# patch drivers/input/Makefile
p = "drivers/input/Makefile"
s = open(p, encoding="utf-8").read()
objline = "obj-$(CONFIG_MICROARRAY_FINGERPRINT) += fingerprint/"
if objline not in s:
    s = s.rstrip("\n") + "\n" + objline + "\n"
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must(objline in open(p).read(), "drivers/input/Makefile has fingerprint obj")

# ---------- 2. sleep debuglog ----------
sd = "drivers/misc"
data = None
for src in ("../r38_overlay/sleep/sprd_debuglog.c", "r38_overlay/sleep/sprd_debuglog.c"):
    if os.path.exists(src):
        data = open(src, encoding="utf-8").read()
        break
must(data is not None, "sprd_debuglog.c source not found")
open(os.path.join(sd, "sprd_debuglog.c"), "w", encoding="utf-8", newline="\n").write(data)

p = "drivers/misc/Kconfig"
s = open(p, encoding="utf-8").read()
if "SPRD_DEBUGLOG" not in s:
    block = (
"config SPRD_DEBUGLOG\n"
"\tbool \"W527 sleep monitor / power-state debug framework\"\n"
"\tdefault y\n"
"\thelp\n"
"\t  W527 factory-spec sleep monitor framework (ap_sleep_condition_check,\n"
"\t  wakeup_info registry, sleep notifier). Internal diagnostics only.\n"
"\n")
    idx = s.find("endmenu")
    if idx >= 0:
        s = s[:idx] + block + s[idx:]
    else:
        s = s.rstrip("\n") + "\n\n" + block
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must("SPRD_DEBUGLOG" in open(p).read(), "drivers/misc/Kconfig has SPRD_DEBUGLOG")

p = "drivers/misc/Makefile"
s = open(p, encoding="utf-8").read()
if "sprd_debuglog" not in s:
    s = s.rstrip("\n") + "\nobj-$(CONFIG_SPRD_DEBUGLOG) += sprd_debuglog.o\n"
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must("sprd_debuglog" in open(p).read(), "drivers/misc/Makefile has sprd_debuglog")

# ---------- 3. config ----------
cfg = None
for c in ("../w527.config", "w527.config"):
    if os.path.exists(c):
        cfg = c; break
must(cfg is not None, "config file located: " + str(cfg))
s = open(cfg, encoding="utf-8").read()
for k in ("CONFIG_MICROARRAY_FINGERPRINT=y", "CONFIG_INPUT_FINGERPRINT=y",
          "CONFIG_SPRD_DEBUGLOG=y"):
    if k not in s:
        s = s.rstrip("\n") + "\n" + k + "\n"
open(cfg, "w", encoding="utf-8", newline="\n").write(s)
s2 = open(cfg).read()
for k in ("CONFIG_MICROARRAY_FINGERPRINT=y", "CONFIG_INPUT_FINGERPRINT=y",
          "CONFIG_SPRD_DEBUGLOG=y"):
    must(k in s2, "config has " + k)

print("\nr38 port complete.")
