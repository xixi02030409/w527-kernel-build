#!/usr/bin/env python3
"""r37 overlay 挂接脚本：在 atlas4381 xintaiqi 树上挂 eta6947-charger。
module.c / sc27xx_fuel_gauge.c / eta6947-charger.c 由 tar 直接落位，无需修改。
此处只做 Kconfig + Makefile 挂接与验证。
"""
import os, sys

ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'

def append_once(path, text, tag):
    s = open(path, encoding='utf-8', errors='replace').read()
    key = text.strip().splitlines()[0]
    if key in s:
        print('[skip] %s already present' % tag)
        return
    if not s.endswith('\n'):
        s += '\n'
    open(path, 'a', encoding='utf-8').write(text + '\n')
    print('[patch] %s appended' % tag)

# 1) Kconfig: CHARGER_ETA6947（与 ZDC 树定义一致）
kconfig = 'drivers/power/supply/Kconfig'
append_once(kconfig, '''config CHARGER_ETA6947
\ttristate "ETA6947 battery charger driver"
\tdepends on I2C
\thelp
\t  Say Y here to enable support for the ETA6947 standalone
\t  battery charger. This driver provides charging and OTG
\t  support for W527 (non-removable battery).''', 'eta6947-kconfig')

# 2) Makefile: obj 行
makefile = 'drivers/power/supply/Makefile'
append_once(makefile, 'obj-$(CONFIG_CHARGER_ETA6947)\t+= eta6947-charger.o', 'eta6947-makefile')

# 3) 验证
checks = [
    ('kernel/module.c', 'module_layout version mismatch, FORCING load'),
    ('drivers/power/supply/sc27xx_fuel_gauge.c', 'bat_present = true'),
    ('drivers/power/supply/eta6947-charger.c', 'eta6947_charger_probe'),
    (kconfig, 'config CHARGER_ETA6947'),
    (makefile, 'eta6947-charger.o'),
]
for path, needle in checks:
    s = open(os.path.join(ROOT, path), encoding='utf-8', errors='replace').read()
    if needle not in s:
        print('VERIFY FAILED: %s missing %r' % (path, needle))
        sys.exit(1)
    print('[ok] %s contains %r' % (path, needle))
print('r37 overlay port DONE')
