#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# r43 overlay: bd1860 full driver (factory behavior 1:1, replaces r42 probe stub)
# installs drivers/misc/bd1860/bd1860.c + Kconfig/Makefile + CONFIG_BD1860=y

import os, re, sys

def must(cond, msg):
    if not cond:
        print("FAIL: " + msg)
        sys.exit(1)
    print("OK: " + msg)

fp = os.getcwd()
sd = os.path.join(fp, "drivers/misc/bd1860")
os.makedirs(sd, exist_ok=True)

# 1. driver source (full r43 driver, replaces stub bd1860_probe.c)
src = open(os.path.join(fp, "r43_overlay/bd1860.c"), encoding="utf-8").read()
open(os.path.join(sd, "bd1860.c"), "w", encoding="utf-8", newline="\n").write(src)
must("bd_data_read_mode2" in src, "r43 full driver installed")
# remove r42 stub if present (fresh clone of same branch may carry it via repo state)
old = os.path.join(sd, "bd1860_probe.c")
if os.path.exists(old):
    os.remove(old)
    print("OK: r42 stub bd1860_probe.c removed")

# 2. Kconfig
kc = ("config BD1860\n"
      "\tbool \"BD1860 heart-rate sensor driver, factory 1:1 (W527)\"\n"
      "\tdepends on I2C\n"
      "\tdefault y\n"
      "\thelp\n"
      "\t  BD1860 HR sensor: factory-transaction driver with input device,\n"
      "\t  class/bd1860/device hrenable+hrtest, polling pump, AGC. Health\n"
      "\t  algorithm lands in r44.\n")
open(os.path.join(sd, "Kconfig"), "w", encoding="utf-8", newline="\n").write(kc)

# 3. Makefile
mk = "obj-$(CONFIG_BD1860) += bd1860.o\n"
open(os.path.join(sd, "Makefile"), "w", encoding="utf-8", newline="\n").write(mk)

# 4. wire drivers/misc/Kconfig + Makefile (idempotent)
p = os.path.join(fp, "drivers/misc/Kconfig")
s = open(p, encoding="utf-8").read()
for line in ('source "drivers/misc/bd1860/Kconfig"',):
    if line not in s:
        if 'source "drivers/misc/hxd019' in s:
            idx = s.find('source "drivers/misc/hxd019')
            idx = s.find("\n", idx) + 1
            s = s[:idx] + line + "\n" + s[idx:]
        else:
            s = s.rstrip("\n") + "\n" + line + "\n"
        open(p, "w", encoding="utf-8", newline="\n").write(s)
must('source "drivers/misc/bd1860/Kconfig"' in open(p).read(), "misc/Kconfig sources bd1860")

p = os.path.join(fp, "drivers/misc/Makefile")
s = open(p, encoding="utf-8").read()
changed = False
if "obj-$(CONFIG_BD1860_PROBE) += bd1860/" in s:
    s = s.replace("obj-$(CONFIG_BD1860_PROBE) += bd1860/", "obj-$(CONFIG_BD1860) += bd1860/")
    changed = True
if "obj-$(CONFIG_BD1860) += bd1860/" not in s:
    s = s.rstrip("\n") + "\n" + "obj-$(CONFIG_BD1860) += bd1860/\n"
    changed = True
if changed:
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must("obj-$(CONFIG_BD1860) += bd1860/" in open(p).read(), "misc/Makefile has bd1860 obj")

# 5. config: swap CONFIG_BD1860_PROBE -> CONFIG_BD1860
cfg = None
for c in ("../w527.config", "w527.config"):
    if os.path.exists(c):
        cfg = c
        break
must(cfg is not None, "w527.config found")
s = open(cfg, encoding="utf-8").read()
if "CONFIG_BD1860_PROBE=y" in s:
    s = s.replace("CONFIG_BD1860_PROBE=y", "CONFIG_BD1860=y")
elif "CONFIG_BD1860=y" not in s:
    s = s.rstrip("\n") + "\nCONFIG_BD1860=y\n"
open(cfg, "w", encoding="utf-8", newline="\n").write(s)
must("CONFIG_BD1860=y" in open(cfg).read(), "w527.config has CONFIG_BD1860=y")

print("r43 overlay port complete")
