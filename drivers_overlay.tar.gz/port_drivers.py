# -*- coding: utf-8 -*-
"""W527 驱动移植脚本（幂等）：qmc6308 磁力计 + mir3da G-sensor + eta6947 充电 IC
在内核树根目录运行: python port_drivers.py
"""
import os, sys, io

TREE = sys.argv[1] if len(sys.argv) > 1 else '.'
IM = os.path.join(TREE, 'drivers/input/misc')

def read(p):
    with io.open(p, encoding='utf-8', errors='replace') as f:
        return f.read()

def write(p, s):
    with io.open(p, 'w', encoding='utf-8', newline='\n') as f:
        f.write(s)

ok = True

# ---------- 1. qmc6308.c: 补 misc 名宏 + of_match 加 W527 compatible ----------
p = os.path.join(IM, 'qmc6308/qmc6308.c')
s = read(p)
if 'QMC_MISCDEV_NAME' in s and '#define QMC_MISCDEV_NAME' not in s:
    s = s.replace('static struct miscdevice qmc_compass_dev = {',
                  '#define QMC_MISCDEV_NAME "qmc6308" /* W527 HAL opens /dev/qmc6308 */\n\nstatic struct miscdevice qmc_compass_dev = {', 1)
    print('[patch] qmc6308.c: QMC_MISCDEV_NAME defined')
if '"qst,qmc6308"' in s and '"qmc,qmc6308"' not in s:
    s = s.replace('{ .compatible = "qst,qmc6308", },',
                  '{ .compatible = "qst,qmc6308", },\n\t{ .compatible = "qmc,qmc6308", }, /* W527 dtb */', 1)
    print('[patch] qmc6308.c: of_match += qmc,qmc6308')
# linux/i2c-dev.h 是用户态头，内核里可能不存在
if '#include <linux/i2c-dev.h>' in s:
    s = s.replace('#include <linux/i2c-dev.h>', '/* #include <linux/i2c-dev.h> removed: userspace header */', 1)
    print('[patch] qmc6308.c: drop userspace i2c-dev.h include')
write(p, s)

# ---------- 2. mir3da_cust.c: of_match 加 da,da217 ----------
p = os.path.join(IM, 'mir3da/mir3da_cust.c')
s = read(p)
if '"da,da213"' in s and '"da,da217"' not in s:
    s = s.replace('{ .compatible = "da,da213", },',
                  '{ .compatible = "da,da213", },\n\t{ .compatible = "da,da217", }, /* W527 gsensor */', 1)
    print('[patch] mir3da_cust.c: of_match += da,da217')
write(p, s)

# ---------- 3. input/misc Makefile 追加 ----------
p = os.path.join(IM, 'Makefile')
s = read(p)
add = []
if 'qmc6308.o' not in s:
    add.append('obj-$(CONFIG_SENSORS_QMC6308) += qmc6308/qmc6308.o')
if 'mir3da.o' not in s:
    add.append('obj-$(CONFIG_INPUT_MIR3DA) += mir3da/mir3da.o\nmir3da-y := mir3da/mir3da_core.o mir3da/mir3da_cust.o')
if add:
    s = s.rstrip('\n') + '\n# W527 drivers\n' + '\n'.join(add) + '\n'
    write(p, s)
    print('[patch] input/misc/Makefile: +', len(add), 'lines')

# ---------- 4. input/misc Kconfig 追加 ----------
p = os.path.join(IM, 'Kconfig')
s = read(p)
need = []
if 'SENSORS_QMC6308' not in s:
    need.append('''config SENSORS_QMC6308
	tristate "QST QMC6308 magnetic sensor (W527)"
	depends on I2C=y
	default y
	help
	  QST QMC6308 3-axis magnetometer via misc device /dev/qmc6308.
''')
if 'config INPUT_MIR3DA' not in s:
    need.append('''config INPUT_MIR3DA
	tristate "MIR3DA/DA217 gsensor (W527)"
	depends on I2C=y
	default y
	help
	  Davicom mir3da series (DA217) 3-axis accelerometer,
	  misc device /dev/mir3da plus input events.
''')
if need:
    s = s.rstrip('\n') + '\n# W527 drivers\n' + '\n'.join(need)
    write(p, s)
    print('[patch] input/misc/Kconfig: +', len(need), 'blocks')

# ---------- 5. eta6947 Kconfig default y（树内已有驱动，只是没开） ----------
p = os.path.join(TREE, 'drivers/power/supply/Kconfig')
s = read(p)
if 'config CHARGER_ETA6947' in s and 'W527-default-y' not in s:
    # 不改 default，靠 config 打开即可；此步仅占位提示
    print('[info] CHARGER_ETA6947 exists in Kconfig; enable via defconfig')

print('PORT DONE')
