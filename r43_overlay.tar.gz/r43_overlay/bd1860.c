// bd1860.c - W527 r43: BD1860 heart-rate sensor driver (factory behavior 1:1)
//
// Everything here is transcribed from the factory kernel binary
// (bd1860_survey/REVERSE_NOTES.md sections 7.1 / 9.5 / 10). The transaction
// sequence and control flow are replicated verbatim, so behavior does not
// depend on our interpretation of register semantics.
//
// Structure (factory-verified):
//   probe            : i2c bind (DTB compatible "bd,bd1860"), input dev "bd1860",
//                      class/bd1860/device/{hrenable,hrtest} + debug {dump,id,reg}
//   hrenable 1       : BD_Sensor_Init(mode 2) + polling kthread pump
//   hrenable 0       : BD_Sensor_Close (07=00, E8=01)
//   polling kthread  : wait_for_completion -> dataread -> re-arm -> usleep 46ms
//                      (factory cycle 63ms = 46ms sleep + i2c time, 15.9Hz)
//   dataread mode2   : chA direct reads 0x27/28/29 (PPG24) + 0x2e/2f (aux16)
//                      chB: if AGC adjusting -> wr 0x17/0x18=curA + EB latch,
//                           then reads 0x32/33/34 (PPG24) + 0x39/3a (aux16)
//                      chC: if AGC adjusting -> wr 0x19/0x1a=curB + EB latch,
//                           then reads 0x3d/3e/3f (PPG24) + 0x44/45 (aux16)
//                      per-channel AGC: settle window (0x2903,0x34bc],
//                      step +-5 (aux<=0x1b57 / aux>0x3c8c) else +-1,
//                      cur caps (0x77, 6], activation window !(0x2133,0x3a98]
//                      19-frame history gate before hp mirrors are refreshed
//   frame print      : factory line=257 25-value format (result[] slots) +
//                      r43 raw-pipeline line for A/B verification vs factory_ab
//                      result[0..4] stay 0 until health algorithm is ported (r44)
//   input            : EV_ABS codes 0..4 from result[0..4] + EV_SYN (factory)

#include <linux/module.h>
#include <linux/i2c.h>
#include <linux/slab.h>
#include <linux/mutex.h>
#include <linux/sysfs.h>
#include <linux/device.h>
#include <linux/uaccess.h>
#include <linux/kernel.h>
#include <linux/string.h>
#include <linux/input.h>
#include <linux/kthread.h>
#include <linux/completion.h>
#include <linux/delay.h>

#define BD_DRV_NAME		"bd1860"
#define BD_CLASS_NAME		"bd1860"
#define BD_DEV_NAME		"device"

#define BD_RING_LEN		20	/* per-channel ring buffers (factory 0x13+1) */
#define BD_HIST_GATE		18	/* factory: [0x5bc] <= 0x12 -> accumulate	*/
#define BD_POLL_US		46000	/* factory usleep_range(0xb3b0, 0xb3b0)	*/

#define BD_AGC_SETTLE_LO	0x2903	/* wide settle window low (exclusive)	*/
#define BD_AGC_SETTLE_HI	0x34bc	/* wide settle window high (inclusive)	*/
#define BD_AGC_STEP_LO		0x1b57	/* aux <= this -> step 5		*/
#define BD_AGC_STEP_HI		0x3c8c	/* aux >  this -> step 5		*/
#define BD_AGC_ACT_LO		0x2133	/* activation window low (exclusive)	*/
#define BD_AGC_ACT_HI		0x3a98	/* activation window high (inclusive)	*/
#define BD_AGC_CUR_MAX		0x77	/* current upper cap			*/
#define BD_AGC_CUR_MIN		6	/* current lower cap			*/

/* factory BD_Sensor_Init mode2 table (reg, val); 14/15/16 = caller buf,
 * 17/18 = curA, 19/1A = curB patched per-call */
static const u8 bd_init_mode2[][2] = {
	{ 0x03, 0x80 },	/* mode2 ignition (mode 0xd/others use 0xA0)	*/
	{ 0x04, 0x05 },	{ 0x05, 0x00 },
	{ 0x12, 0x01 },	{ 0x13, 0x00 },
	{ 0x08, 0x00 },	{ 0x09, 0x01 },	{ 0x0A, 0x00 },
	{ 0x0B, 0x01 },	{ 0x0C, 0x00 },	{ 0x0D, 0x01 },
	{ 0x0E, 0x28 },	{ 0x0F, 0x28 },	{ 0x10, 0x0A },	{ 0x11, 0x77 },
	{ 0x14, 0x12 },	{ 0x15, 0x12 },	{ 0x16, 0x12 },	/* caller buf	*/
	{ 0x17, 0x60 },	{ 0x18, 0x00 },				/* curA		*/
	{ 0x19, 0x60 },	{ 0x1A, 0x00 },				/* curB		*/
	{ 0x1B, 0x10 },	{ 0x1C, 0x00 },
	{ 0x1D, 0x4F },	{ 0x1E, 0x2F },	{ 0x1F, 0x4F },
	{ 0x22, 0x00 },
	{ 0x26, 0x00 },
	{ 0xEB, 0x80 },
	{ 0x07, 0x01 },	/* kick */
};

struct bd_chan {
	u16	cur;			/* LED current / mux value			*/
	u8	retry;			/* AGC adjusting (factory 0x662/0x663)		*/
	u8	active;			/* AGC ran in window (factory 0x665/0x666)	*/
	s32	ppg[BD_RING_LEN];	/* PPG24 ring (factory 0x668/0x6d0/0x738)	*/
	u16	aux[BD_RING_LEN];	/* aux16 ring (factory 0x5c0/0x5f8/0x630)	*/
	/* health-pro input mirrors (factory 0x7a0/0x808/0x870) */
	s32	hp_ppg[BD_RING_LEN];
	s32	hp_auxsum;		/* +0x50: last-4 aux average>>2 sum		*/
	s32	hp_cur;			/* +0x54: current value snapshot		*/
	s32	hp_flag;		/* +0x58: active flag snapshot			*/
};

struct bd_state {
	struct i2c_client	*cli;
	struct input_dev	*input;
	struct class		*cls;
	struct device		*clsdev;
	struct completion	comp;
	struct task_struct	*poll_task;
	struct mutex		lock;

	int			enabled;	/* factory +4 hr_is_enable	*/
	int			mode;		/* factory +8 test_kinds	*/

	int			frame_cnt;	/* factory [0x5bc]		*/
	struct bd_chan		ch[3];		/* A/B/C			*/
	u16			curC;		/* factory [0x69e] (static r43)	*/

	int			result[25];	/* factory g+0x70		*/

	s32			raw_ppg[3];	/* last-frame raw snapshot	*/
	u16			raw_aux[3];
};

static struct bd_state *bds;

/* ---------- i2c primitives (factory BD_I2C_Write / BD_I2C_Read) ---------- */

static int bd_wr(struct i2c_client *cli, u8 reg, u8 val)
{
	u8 buf[2] = { reg, val };
	int ret = i2c_master_send(cli, buf, 2);

	return (ret == 2) ? 0 : (ret < 0 ? ret : -EIO);
}

static int bd_rd(struct i2c_client *cli, u8 reg)
{
	return i2c_smbus_read_byte_data(cli, reg);
}

/* ---------- BD_Sensor_Init (factory 1:1; mode2 fully traced) ---------- */

static int bd_sensor_init(struct bd_state *s, int mode)
{
	struct i2c_client *cli = s->cli;
	int i, ret;

	/* preamble: E8=0, EE=7, delay 10ms, E8=0 (all factory branches) */
	ret = bd_wr(cli, 0xE8, 0x00); if (ret) return ret;
	ret = bd_wr(cli, 0xEE, 0x07); if (ret) return ret;
	msleep(10);
	ret = bd_wr(cli, 0xE8, 0x00); if (ret) return ret;

	for (i = 0; i < ARRAY_SIZE(bd_init_mode2); i++) {
		u8 reg = bd_init_mode2[i][0];
		u8 val = bd_init_mode2[i][1];

		switch (reg) {
		case 0x17: val = s->ch[0].cur & 0xff; break;
		case 0x18: val = (s->ch[0].cur >> 8) & 0xff; break;
		case 0x19: val = s->ch[1].cur & 0xff; break;
		case 0x1A: val = (s->ch[1].cur >> 8) & 0xff; break;
		}
		ret = bd_wr(cli, reg, val);
		if (ret)
			return ret;
	}

	/* factory init entry presets + state reset */
	s->ch[0].cur = 0x60;		/* [0x6cc] = 0x60	*/
	s->ch[1].cur = 0x60;		/* [0x612] = 0x60	*/
	s->curC      = 0x60;		/* [0x69e] = 0x60	*/
	s->ch[0].retry = 0;
	s->ch[1].retry = 0;
	s->ch[0].active = 0;
	s->ch[1].active = 0;
	s->frame_cnt = 0;
	s->mode = mode;

	pr_info("[gxy_bd1860] BD_16XX_init_start: temp1 = 1, temp2 = 1, temp3 = 1\n");
	return 0;
}

/* ---------- BD_Sensor_Close (factory 1:1: 07=00 then E8=01) ---------- */

static void bd_sensor_close(struct bd_state *s)
{
	bd_wr(s->cli, 0x07, 0x00);
	bd_wr(s->cli, 0xE8, 0x01);
	pr_info("[gxy_bd1860] BD_16XX_close 230 : start\n");
}

/* ---------- per-channel AGC (factory control flow verbatim) ---------- */

static void bd_agc_adjust(struct bd_chan *ch, int idx)
{
	u16 aux = ch->aux[idx];

	ch->active = 1;					/* [0x665]/[0x666]=1 */

	if (aux > BD_AGC_SETTLE_LO && aux <= BD_AGC_SETTLE_HI) {
		ch->retry = 0;				/* settled	*/
		return;
	}
	if (aux <= BD_AGC_SETTLE_LO) {
		if (ch->cur <= BD_AGC_CUR_MAX)
			ch->cur += (aux <= BD_AGC_STEP_LO) ? 5 : 1;
	} else {					/* aux > SETTLE_HI	*/
		if (ch->cur > BD_AGC_CUR_MIN)
			ch->cur -= (aux > BD_AGC_STEP_HI) ? 5 : 1;
	}
}

static void bd_agc_setcheck(struct bd_chan *ch, int idx)
{
	u16 aux = ch->aux[idx];

	if (aux <= BD_AGC_ACT_LO || aux > BD_AGC_ACT_HI)
		ch->retry = 1;				/* start adjusting	*/
}

/* ---------- BD_Sensor_Data_Read (factory mode==2 block, verbatim) ---------- */

static int bd_data_read_mode2(struct bd_state *s)
{
	struct i2c_client *cli = s->cli;
	struct bd_chan *A = &s->ch[0];
	struct bd_chan *B = &s->ch[1];
	struct bd_chan *C = &s->ch[2];
	int idx = s->frame_cnt % BD_RING_LEN;
	int i, sum;

	/* ---- group A: direct pre-reads (unconditional) ---- */
	{
		int b0 = bd_rd(cli, 0x27);
		int b1 = bd_rd(cli, 0x28);
		int b2 = bd_rd(cli, 0x29);
		int a0 = bd_rd(cli, 0x2e);
		int a1 = bd_rd(cli, 0x2f);

		if (b0 < 0 || b1 < 0 || b2 < 0 || a0 < 0 || a1 < 0)
			return 0;
		A->ppg[idx] = b0 | (b1 << 8) | (b2 << 16);
		A->aux[idx] = ((a0 >> 2) & 0xff) + ((a1 & 0x3ff) << 6);
	}
	if (s->frame_cnt == 0)
		A->active = 0;			/* factory [0x665]	*/

	if (A->retry)
		bd_agc_adjust(A, idx);
	if (A->retry) {				/* still adjusting -> write */
		bd_wr(cli, 0x17, A->cur & 0xff);
		bd_wr(cli, 0x18, (A->cur >> 8) & 0xff);
		bd_wr(cli, 0xEB, 0x80);
	} else {
		bd_agc_setcheck(A, idx);
	}

	/* ---- group B reads (unconditional) ---- */
	{
		int b0 = bd_rd(cli, 0x32);
		int b1 = bd_rd(cli, 0x33);
		int b2 = bd_rd(cli, 0x34);
		int a0 = bd_rd(cli, 0x39);
		int a1 = bd_rd(cli, 0x3a);

		if (b0 < 0 || b1 < 0 || b2 < 0 || a0 < 0 || a1 < 0)
			return 0;
		B->ppg[idx] = b0 | (b1 << 8) | (b2 << 16);
		B->aux[idx] = ((a0 >> 2) & 0xff) + ((a1 & 0x3ff) << 6);
	}
	if (s->frame_cnt == 0)
		B->active = 0;			/* factory [0x666]	*/

	if (B->retry)
		bd_agc_adjust(B, idx);
	if (B->retry) {				/* still adjusting -> write */
		bd_wr(cli, 0x19, B->cur & 0xff);
		bd_wr(cli, 0x1a, (B->cur >> 8) & 0xff);
		bd_wr(cli, 0xEB, 0x80);
	} else {
		bd_agc_setcheck(B, idx);
	}

	/* ---- group C reads (unconditional; chC current static in r43) ---- */
	{
		int b0 = bd_rd(cli, 0x3d);
		int b1 = bd_rd(cli, 0x3e);
		int b2 = bd_rd(cli, 0x3f);
		int a0 = bd_rd(cli, 0x44);
		int a1 = bd_rd(cli, 0x45);

		if (b0 < 0 || b1 < 0 || b2 < 0 || a0 < 0 || a1 < 0)
			return 0;
		C->ppg[idx] = b0 | (b1 << 8) | (b2 << 16);
		C->aux[idx] = ((a0 >> 2) & 0xff) + ((a1 & 0x3ff) << 6);
	}
	C->cur = s->curC;

	/* ---- history gate (factory [0x5bc] > 0x12) ---- */
	if (s->frame_cnt <= BD_HIST_GATE) {
		s->frame_cnt++;
		return 0;
	}

	/* ---- refresh health-pro mirrors (factory tail loop) ---- */
	for (i = 0; i < BD_RING_LEN; i++) {
		A->hp_ppg[i] = A->ppg[i];
		B->hp_ppg[i] = B->ppg[i];
		C->hp_ppg[i] = C->ppg[i];
	}
	sum = 0;
	for (i = 16; i < BD_RING_LEN; i++)
		sum += A->aux[i] >> 2;
	A->hp_auxsum = sum;
	sum = 0;
	for (i = 16; i < BD_RING_LEN; i++)
		sum += B->aux[i] >> 2;
	B->hp_auxsum = sum;
	sum = 0;
	for (i = 16; i < BD_RING_LEN; i++)
		sum += C->aux[i] >> 2;
	C->hp_auxsum = sum;

	A->hp_cur = A->cur;
	B->hp_cur = B->cur;
	C->hp_cur = C->cur;
	A->hp_flag = A->active;
	B->hp_flag = B->active;
	C->hp_flag = C->active;

	/* raw snapshot of this frame for debug/A-B */
	s->raw_ppg[0] = A->ppg[idx];
	s->raw_ppg[1] = B->ppg[idx];
	s->raw_ppg[2] = C->ppg[idx];
	s->raw_aux[0] = A->aux[idx];
	s->raw_aux[1] = B->aux[idx];
	s->raw_aux[2] = C->aux[idx];

	s->frame_cnt = 0;
	return 1;			/* factory: ret==1 -> health_pro next */
}

/* ---------- BD_16XX_dataread (factory 1:1 minus health_pro) ---------- */

static void bd_16xx_dataread(struct bd_state *s)
{
	int ret;

	pr_info("[gxy_bd1860] BD_16XX_dataread 242 : start, -------------------\n");

	ret = bd_data_read_mode2(s);
	if (ret != 1)
		return;

	/*
	 * factory: BD_health_pro(mode, 0, 0, result) fills result[0..24].
	 * r43: algorithm not yet ported (r44 campaign). Algorithm output slots
	 * stay 0 (same as factory when signal invalid). Raw pipeline is printed
	 * on a dedicated line for A/B verification against factory_ab logs.
	 */
	memset(s->result, 0, sizeof(s->result));

	{
		int j;

		for (j = 0; j < 25; j++)
			pr_info("gxy_bd1860, func=BD_16XX_dataread, line=257, iRet = %d, test_kinds = %d, bd_data_result[%d] = %d\n",
				1, s->mode, j, s->result[j]);
	}

	pr_info("gxy_bd1860 r43-raw: ppg=[%d %d %d] aux=[%u %u %u] cur=[%d %d %d] hpA=[%d %d %d]\n",
		s->raw_ppg[0], s->raw_ppg[1], s->raw_ppg[2],
		s->raw_aux[0], s->raw_aux[1], s->raw_aux[2],
		s->ch[0].cur, s->ch[1].cur, s->ch[2].cur,
		s->ch[0].hp_auxsum, s->ch[1].hp_auxsum, s->ch[2].hp_auxsum);

	/* input report: EV_ABS codes 0..4 from result[0..4] + SYN (factory) */
	if (s->input) {
		int c;

		for (c = 0; c < 5; c++)
			input_report_abs(s->input, c, s->result[c]);
		input_sync(s->input);
	}
}

/* ---------- polling task (factory BD_16XX_polling_task 1:1) ---------- */

static int bd_poll_task(void *data)
{
	struct bd_state *s = data;

	while (!kthread_should_stop()) {
		wait_for_completion_interruptible(&s->comp);
		bd_16xx_dataread(s);
		if (s->enabled)
			complete(&s->comp);	/* factory re-arm	*/
		usleep_range(BD_POLL_US, BD_POLL_US);
	}
	return 0;
}

/* ---------- sysfs: class/bd1860/device/{hrenable,hrtest} ---------- */

static ssize_t hrenable_show(struct device *dev,
			     struct device_attribute *attr, char *buf)
{
	return scnprintf(buf, PAGE_SIZE, "%d\n", bds ? bds->enabled : 0);
}

static ssize_t hrenable_store(struct device *dev,
			      struct device_attribute *attr,
			      const char *buf, size_t count)
{
	int enable;
	int ret;

	if (!bds)
		return -ENODEV;
	if (kstrtoint(buf, 0, &enable))
		return -EINVAL;

	mutex_lock(&bds->lock);
	pr_info("[gxy_bd1860] hrenable_store 396 : hrenable_store: start, buf[0] = 0x%x, hr_is_enable = %d\n",
		(u8)buf[0], bds->enabled);

	ret = 0;
	if (enable == 1 && !bds->enabled) {
		ret = bd_sensor_init(bds, 2);	/* factory echo '1' -> mode 2 */
		if (!ret) {
			bds->enabled = 1;
			complete(&bds->comp);	/* kick the pump	*/
		}
	} else if (enable == 0 && bds->enabled) {
		bds->enabled = 0;
		bd_sensor_close(bds);
	} else if ((enable == 2 || enable == 3 || enable == 4) && !bds->enabled) {
		/*
		 * factory maps '2'/'3' -> mode 6, '4' -> mode 0xd; those
		 * dataread blocks differ (13 read groups for 0xd). r43 runs
		 * the mode2 pipeline for them too - documented limitation.
		 */
		ret = bd_sensor_init(bds, enable == 4 ? 0xd : 6);
		if (!ret) {
			bds->enabled = 1;
			complete(&bds->comp);
		}
	}
	mutex_unlock(&bds->lock);
	return ret ? ret : count;
}
static DEVICE_ATTR_RW(hrenable);

static ssize_t hrtest_show(struct device *dev,
			   struct device_attribute *attr, char *buf)
{
	/* factory bd1860_test_read_and_write: I2C r/w self test */
	int w, r;

	if (!bds)
		return -ENODEV;
	w = bd_wr(bds->cli, 0x00, 0x00);
	r = bd_rd(bds->cli, 0x00);
	return scnprintf(buf, PAGE_SIZE,
			 "bd1860_test_read_and_write: wr=%d rd=0x%02x %s\n",
			 w, r < 0 ? 0 : r, (w == 0 && r >= 0) ? "OK" : "FAIL");
}
static DEVICE_ATTR_RO(hrtest);

/* ---------- sysfs: debug attrs on i2c dev (kept from r42 stub) ---------- */

static ssize_t bd_dump_show(struct device *dev,
			    struct device_attribute *attr, char *buf)
{
	int i, n = 0;

	mutex_lock(&bds->lock);
	for (i = 0; i < 0x80; i++) {
		int v = bd_rd(bds->cli, (u8)i);

		if (v < 0)
			n += scnprintf(buf + n, PAGE_SIZE - n, "%02x: ERR%d\n",
				       i, v);
		else
			n += scnprintf(buf + n, PAGE_SIZE - n, "%02x: %02x\n",
				       i, v);
		if (n >= PAGE_SIZE - 32)
			break;
	}
	mutex_unlock(&bds->lock);
	return n;
}
static struct device_attribute dev_attr_dump =
		__ATTR(dump, 0444, bd_dump_show, NULL);

static ssize_t bd_id_show(struct device *dev,
			  struct device_attribute *attr, char *buf)
{
	int v[8], i, n = 0;

	mutex_lock(&bds->lock);
	for (i = 0; i < 8; i++) {
		v[i] = bd_rd(bds->cli, (u8)i);
		if (v[i] < 0)
			v[i] = 0xEE;
	}
	mutex_unlock(&bds->lock);
	n = scnprintf(buf, PAGE_SIZE,
		      "reg00-07: %02x %02x %02x %02x %02x %02x %02x %02x\n",
		      v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7]);
	return n;
}
static struct device_attribute dev_attr_id =
		__ATTR(id, 0444, bd_id_show, NULL);

static u8 bd_reg_addr;
static ssize_t bd_reg_show(struct device *dev,
			   struct device_attribute *attr, char *buf)
{
	int v;

	mutex_lock(&bds->lock);
	v = bd_rd(bds->cli, bd_reg_addr);
	mutex_unlock(&bds->lock);
	if (v < 0)
		return v;
	return scnprintf(buf, PAGE_SIZE, "reg 0x%02x = 0x%02x\n",
			 bd_reg_addr, v);
}

static ssize_t bd_reg_store(struct device *dev,
			    struct device_attribute *attr,
			    const char *buf, size_t count)
{
	unsigned int addr = 0, val = 0;
	int items;

	items = sscanf(buf, "%x %x", &addr, &val);
	if (items < 1 || addr > 0xFF)
		return -EINVAL;
	mutex_lock(&bds->lock);
	bd_reg_addr = (u8)addr;
	if (items == 2)
		bd_wr(bds->cli, bd_reg_addr, (u8)val);
	mutex_unlock(&bds->lock);
	return count;
}
static struct device_attribute dev_attr_reg =
		__ATTR(reg, 0644, bd_reg_show, bd_reg_store);

static struct attribute *bd_i2c_attrs[] = {
	&dev_attr_dump.attr,
	&dev_attr_id.attr,
	&dev_attr_reg.attr,
	NULL,
};
static const struct attribute_group bd_i2c_group = { .attrs = bd_i2c_attrs };

/* ---------- probe / remove ---------- */

static int bd_probe(struct i2c_client *cli, const struct i2c_device_id *id)
{
	int ret;

	bds = devm_kzalloc(&cli->dev, sizeof(*bds), GFP_KERNEL);
	if (!bds)
		return -ENOMEM;

	bds->cli = cli;
	mutex_init(&bds->lock);
	init_completion(&bds->comp);

	ret = i2c_smbus_read_byte_data(cli, 0x00);
	if (ret < 0) {
		pr_err("bd1860: i2c read failed at probe: %d\n", ret);
		return ret;
	}
	pr_info("bd1860: probe OK, i2c addr 0x%02x, reg00=0x%02x\n",
		cli->addr, ret);

	/* input device "bd1860" (factory bd1860_input_dev_init) */
	bds->input = devm_input_allocate_device(&cli->dev);
	if (!bds->input)
		return -ENOMEM;
	bds->input->name = "bd1860";
	for (ret = 0; ret <= 5; ret++) {
		input_set_capability(bds->input, EV_ABS, ret);
		input_set_abs_params(bds->input, ret, 0, INT_MAX, 0, 0);
	}
	ret = input_register_device(bds->input);
	if (ret)
		return ret;

	/* class/bd1860/device + hrenable/hrtest (factory layout) */
	bds->cls = class_create(THIS_MODULE, BD_CLASS_NAME);
	if (IS_ERR(bds->cls))
		return PTR_ERR(bds->cls);
	bds->clsdev = device_create(bds->cls, NULL, 0, NULL, BD_DEV_NAME);
	if (IS_ERR(bds->clsdev)) {
		ret = PTR_ERR(bds->clsdev);
		goto err_class;
	}
	ret = device_create_file(bds->clsdev, &dev_attr_hrenable);
	if (ret)
		goto err_clsdev;
	ret = device_create_file(bds->clsdev, &dev_attr_hrtest);
	if (ret)
		goto err_clsdev;

	/* debug attrs on i2c device (r42 stub legacy) */
	ret = sysfs_create_group(&cli->dev.kobj, &bd_i2c_group);
	if (ret)
		goto err_clsdev;

	bds->poll_task = kthread_run(bd_poll_task, bds, "polling-mode-task");
	if (IS_ERR(bds->poll_task)) {
		ret = PTR_ERR(bds->poll_task);
		bds->poll_task = NULL;
		goto err_sysfs;
	}

	return 0;

err_sysfs:
	sysfs_remove_group(&cli->dev.kobj, &bd_i2c_group);
err_clsdev:
	device_destroy(bds->cls, 0);
err_class:
	class_destroy(bds->cls);
	return ret;
}

static int bd_remove(struct i2c_client *cli)
{
	if (bds) {
		if (bds->poll_task)
			kthread_stop(bds->poll_task);
		if (bds->enabled)
			bd_sensor_close(bds);
		sysfs_remove_group(&cli->dev.kobj, &bd_i2c_group);
		if (bds->clsdev) {
			device_remove_file(bds->clsdev, &dev_attr_hrenable);
			device_remove_file(bds->clsdev, &dev_attr_hrtest);
			device_destroy(bds->cls, 0);
		}
		if (bds->cls)
			class_destroy(bds->cls);
		bds = NULL;
	}
	return 0;
}

static const struct i2c_device_id bd_id_table[] = {
	{ BD_DRV_NAME, 0 },
	{ }
};
MODULE_DEVICE_TABLE(i2c, bd_id_table);

static const struct of_device_id bd_of_match[] = {
	{ .compatible = "bd,bd1860" },
	{ }
};
MODULE_DEVICE_TABLE(of, bd_of_match);

static struct i2c_driver bd_driver = {
	.driver = {
		.name = BD_DRV_NAME,
		.of_match_table = bd_of_match,
	},
	.probe = bd_probe,
	.remove = bd_remove,
	.id_table = bd_id_table,
};
module_i2c_driver(bd_driver);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("BD1860 heart-rate driver, factory behavior 1:1 (W527 r43)");
