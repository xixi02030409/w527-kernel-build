#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
r40 overlay: W527 GPU anti-jank patch (devfreq core).

Root cause (r39 on-device evidence):
  /sys/class/devfreq/60000000.gpu is driven by the vendor pvrsrvkm
  (Imagination PowerVR) ko with simple_ondemand, but its load reporting
  never ramps: trans_stat shows a single drop to 384MHz right after boot
  and ZERO transitions afterwards (14+ minutes). GPU runs at less than
  half of its 800MHz top OPP the whole time -> UI jank.
  Also: CONFIG_DEVFREQ_GOV_PERFORMANCE is off, so userspace
  "echo performance > governor" always returned -EINVAL.

Fix (kernel side, devfreq core only - vendor ko untouched):
  In update_devfreq(), right after the normal min/max clamps, force the
  target frequency up to the top OPP of the device named 60000000.gpu.
  Works regardless of which governor the ko registered and regardless
  of sysfs min/max writes; target() is called with the top freq on every
  poll (same call cadence as stock, so no new failure modes).
"""
import sys

SRC = "drivers/devfreq/devfreq.c"
MARK = "W527-r40"

ANCHOR = (
    "\tif (devfreq->max_freq && freq > devfreq->max_freq) {\n"
    "\t\tfreq = devfreq->max_freq;\n"
    "\t\tflags |= DEVFREQ_FLAG_LEAST_UPPER_BOUND; /* Use LUB */\n"
    "\t}\n"
)

BLOCK = (
    "\n"
    "\t/*\n"
    "\t * W527-r40 anti-jank: the vendor pvrsrvkm GPU driver registers its\n"
    "\t * devfreq device with simple_ondemand but its load reporting never\n"
    "\t * ramps (trans_stat: one drop to the lowest OPP right after boot,\n"
    "\t * zero transitions afterwards), so the GPU is stuck at 384MHz -\n"
    "\t * half of its 800MHz top OPP - and the whole UI janks. Force the\n"
    "\t * target frequency up to the top OPP of the GPU device on every\n"
    "\t * update, regardless of governor choice or sysfs min/max limits.\n"
    "\t */\n"
    "\tif (devfreq->profile->freq_table && devfreq->profile->max_state > 0 &&\n"
    "\t    !strncmp(dev_name(&devfreq->dev), \"60000000.gpu\", 12)) {\n"
    "\t\tunsigned int w527_i;\n"
    "\t\tunsigned long w527_top = 0;\n"
    "\n"
    "\t\tfor (w527_i = 0; w527_i < devfreq->profile->max_state; w527_i++)\n"
    "\t\t\tif (devfreq->profile->freq_table[w527_i] > w527_top)\n"
    "\t\t\t\tw527_top = devfreq->profile->freq_table[w527_i];\n"
    "\t\tif (freq && freq < w527_top)\n"
    "\t\t\tfreq = w527_top;\n"
    "\t}\n"
)


def main():
    try:
        with open(SRC, encoding="utf-8") as f:
            src = f.read()
    except OSError as e:
        print("r40 FATAL: cannot read %s: %s" % (SRC, e))
        sys.exit(1)

    if MARK in src:
        print("r40: %s already patched - skip" % SRC)
        return

    n = src.count(ANCHOR)
    if n != 1:
        print("r40 FATAL: anchor count=%d (expect 1) in %s" % (n, SRC))
        sys.exit(1)

    src = src.replace(ANCHOR, ANCHOR + BLOCK)
    with open(SRC, "w", encoding="utf-8", newline="\n") as f:
        f.write(src)

    print("r40: %s patched OK" % SRC)
    for ln in src.splitlines():
        if "60000000.gpu" in ln or MARK in ln:
            print("   |", ln)


main()
