#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# r44 overlay: bd1860 driver (r43 pipeline) + decompiled health algorithm cluster
# installs drivers/misc/bd1860/{bd1860.c,bd1860_alg.c,bd1860_alg.h}

import os, sys

def must(cond, msg):
    if not cond:
        print("FAIL: " + msg)
        sys.exit(1)
    print("OK: " + msg)

fp = os.getcwd()
sd = os.path.join(fp, "drivers/misc/bd1860")
os.makedirs(sd, exist_ok=True)

# 1. driver sources
src = open(os.path.join(fp, "r44_overlay/bd1860.c"), encoding="utf-8").read()
open(os.path.join(sd, "bd1860.c"), "w", encoding="utf-8", newline="\n").write(src)
must("BD_health_pro" in src and "BD_Sensor_Data_Read" in src, "r44 factory-chip shell installed")

alg = open(os.path.join(fp, "r44_overlay/bd1860_alg.c"), encoding="utf-8").read()
open(os.path.join(sd, "bd1860_alg.c"), "w", encoding="utf-8", newline="\n").write(alg)
must("BD_health_pro" in alg and "BD_Sensor_Data_Read" in alg, "bd1860_alg.c installed")

algh = open(os.path.join(fp, "r44_overlay/bd1860_alg.h"), encoding="utf-8").read()
open(os.path.join(sd, "bd1860_alg.h"), "w", encoding="utf-8", newline="\n").write(algh)
must("BD_health_pro" in algh, "bd1860_alg.h installed")

# 2. Kconfig
kc = ("config BD1860\n"
      "\tbool \"BD1860 heart-rate sensor driver + decompiled health algorithm (W527)\"\n"
      "\tdepends on I2C\n"
      "\tdefault y\n"
      "\thelp\n"
      "\t  BD1860 HR sensor: factory-transaction driver (r43 pipeline) with\n"
      "\t  r44 decompiled health algorithm cluster (FFT/IIR/HR/HRV/SPO2/BP).\n")
open(os.path.join(sd, "Kconfig"), "w", encoding="utf-8", newline="\n").write(kc)

# 3. Makefile
mk = "obj-$(CONFIG_BD1860) += bd1860.o bd1860_alg.o\n"
open(os.path.join(sd, "Makefile"), "w", encoding="utf-8", newline="\n").write(mk)

# 4. wire drivers/misc/Kconfig + Makefile (idempotent)
p = os.path.join(fp, "drivers/misc/Kconfig")
s = open(p, encoding="utf-8").read()
line = 'source "drivers/misc/bd1860/Kconfig"'
if line not in s:
    if 'source "drivers/misc/hxd019' in s:
        idx = s.find('source "drivers/misc/hxd019')
        idx = s.find("\n", idx) + 1
        s = s[:idx] + line + "\n" + s[idx:]
    else:
        s = s.rstrip("\n") + "\n" + line + "\n"
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must(line in open(p).read(), "misc/Kconfig sources bd1860")

p = os.path.join(fp, "drivers/misc/Makefile")
s = open(p, encoding="utf-8").read()
changed = False
for old, new in (("obj-$(CONFIG_BD1860_PROBE) += bd1860/", "obj-$(CONFIG_BD1860) += bd1860/"),):
    if old in s:
        s = s.replace(old, new)
        changed = True
if "obj-$(CONFIG_BD1860) += bd1860/" not in s:
    s = s.rstrip("\n") + "\n" + "obj-$(CONFIG_BD1860) += bd1860/\n"
    changed = True
if changed:
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must("obj-$(CONFIG_BD1860) += bd1860/" in open(p).read(), "misc/Makefile has bd1860 obj")

# 5. config
cfg = None
for c in ("../w527.config", "w527.config"):
    if os.path.exists(c):
        cfg = c
        break
must(cfg is not None, "w527.config found")
s = open(cfg, encoding="utf-8").read()
if "CONFIG_BD1860_PROBE=y" in s:
    s = s.replace("CONFIG_BD1860_PROBE=y", "CONFIG_BD1860=y")
elif "CONFIG_BD1860=y" not in s:
    s = s.rstrip("\n") + "\nCONFIG_BD1860=y\n"
open(cfg, "w", encoding="utf-8", newline="\n").write(s)
must("CONFIG_BD1860=y" in open(cfg).read(), "w527.config has CONFIG_BD1860=y")

# 6. r48: och1970 REMOVED. The tree's och1970.c is an OCH1970-family
#    magnetometer/gesture driver whose register map does NOT match the
#    real sip1202w@3-0058 hardware (probe RMW writes zeroed 0x20-0x4f
#    every boot; chip answers b3 11 at WIA+2, expects 48 C0 at WIA --
#    never matches, yet bound via an unreliable smbus-block read).
#    Neutralize: config off + delete any installed source. The correct
#    driver is factory's custom code inside the as1509 file -- r49 job.
s2 = open(cfg, encoding="utf-8").read()
if "CONFIG_SENSORS_OCH1970=y" in s2:
    s2 = s2.replace("CONFIG_SENSORS_OCH1970=y", "CONFIG_SENSORS_OCH1970=n")
    open(cfg, "w", encoding="utf-8", newline="\n").write(s2)
must("CONFIG_SENSORS_OCH1970=y" not in open(cfg).read(),
     "w527.config has CONFIG_SENSORS_OCH1970 disabled")

ochp = os.path.join(fp, "drivers/input/misc/och1970.c")
if os.path.exists(ochp):
    os.remove(ochp)
    print("removed leftover drivers/input/misc/och1970.c")

print("r44 overlay port complete (r48: -och1970)")
