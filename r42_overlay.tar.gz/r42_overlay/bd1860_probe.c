// bd1860_probe.c - W527 r42: BD1860 heart-rate sensor probe stub
// purpose: confirm hardware ACK at i2c2@0x40, dump raw registers,
// provide reg R/W passthrough for factory reverse-engineering.
// NOT a full HR driver - algorithm port is a separate campaign.

#include <linux/module.h>
#include <linux/i2c.h>
#include <linux/slab.h>
#include <linux/mutex.h>
#include <linux/sysfs.h>
#include <linux/device.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/kernel.h>
#include <linux/string.h>

#define BD_DRV_NAME "bd1860"
#define BD_CLASS_NAME "bd1860"

static struct i2c_client *bd_client;
static DEFINE_MUTEX(bd_lock);
static u8 bd_reg_addr;

static int bd_read_reg(struct i2c_client *cli, u8 reg, u8 *val)
{
	int ret = i2c_smbus_read_byte_data(cli, reg);
	if (ret < 0)
		return ret;
	*val = (u8)ret;
	return 0;
}

static int bd_write_reg(struct i2c_client *cli, u8 reg, u8 val)
{
	return i2c_smbus_write_byte_data(cli, reg, val);
}

/* sysfs: hex dump of registers 0x00..0x7F */
static ssize_t bd_dump_show(struct device *dev,
			    struct device_attribute *attr, char *buf)
{
	u8 v;
	int ret, i, n = 0;

	mutex_lock(&bd_lock);
	for (i = 0; i < 0x80; i++) {
		ret = bd_read_reg(bd_client, (u8)i, &v);
		if (ret) {
			n += scnprintf(buf + n, PAGE_SIZE - n,
				       "%02x: ERR%d\n", i, ret);
			if (n >= PAGE_SIZE - 32)
				break;
			continue;
		}
		n += scnprintf(buf + n, PAGE_SIZE - n, "%02x: %02x\n", i, v);
		if (n >= PAGE_SIZE - 32)
			break;
	}
	mutex_unlock(&bd_lock);
	return n;
}
static DEVICE_ATTR(dump, 0664, bd_dump_show, NULL);

/* sysfs: reg address selector (+ optional write) */
static ssize_t bd_reg_show(struct device *dev,
			   struct device_attribute *attr, char *buf)
{
	u8 v;
	int ret;

	mutex_lock(&bd_lock);
	ret = bd_read_reg(bd_client, bd_reg_addr, &v);
	mutex_unlock(&bd_lock);
	if (ret)
		return ret;
	return scnprintf(buf, PAGE_SIZE, "reg 0x%02x = 0x%02x\n",
			 bd_reg_addr, v);
}
static ssize_t bd_reg_store(struct device *dev,
			    struct device_attribute *attr,
			    const char *buf, size_t count)
{
	unsigned int addr = 0, val = 0;
	int items;

	items = sscanf(buf, "%x %x", &addr, &val);
	if (items < 1 || addr > 0xFF)
		return -EINVAL;

	mutex_lock(&bd_lock);
	bd_reg_addr = (u8)addr;
	if (items == 2)
		bd_write_reg(bd_client, bd_reg_addr, (u8)val);
	mutex_unlock(&bd_lock);
	return count;
}
static DEVICE_ATTR(reg, 0664, bd_reg_show, bd_reg_store);

/* sysfs: chip id quick probe */
static ssize_t bd_id_show(struct device *dev,
			  struct device_attribute *attr, char *buf)
{
	u8 v[8] = {0};
	int ret, i, n = 0;

	mutex_lock(&bd_lock);
	for (i = 0; i < 8; i++) {
		ret = bd_read_reg(bd_client, (u8)i, &v[i]);
		if (ret)
			v[i] = 0xEE;
	}
	mutex_unlock(&bd_lock);
	n = scnprintf(buf, PAGE_SIZE,
		      "reg00-07: %02x %02x %02x %02x %02x %02x %02x %02x\n",
		      v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7]);
	return n;
}
static DEVICE_ATTR(id, 0664, bd_id_show, NULL);

static struct attribute *bd_attrs[] = {
	&dev_attr_dump.attr,
	&dev_attr_reg.attr,
	&dev_attr_id.attr,
	NULL,
};
static const struct attribute_group bd_group = { .attrs = bd_attrs };

static int bd_probe(struct i2c_client *cli, const struct i2c_device_id *id)
{
	int ret;

	bd_client = cli;
	bd_reg_addr = 0;

	ret = i2c_smbus_read_byte_data(cli, 0x00);
	if (ret < 0) {
		pr_err("bd1860: i2c read failed at probe: %d\n", ret);
		return ret;
	}
	pr_info("bd1860: probe OK, i2c addr 0x%02x, reg00=0x%02x\n",
		cli->addr, ret);

	ret = sysfs_create_group(&cli->dev.kobj, &bd_group);
	if (ret)
		return ret;

	return 0;
}

static int bd_remove(struct i2c_client *cli)
{
	sysfs_remove_group(&cli->dev.kobj, &bd_group);
	bd_client = NULL;
	return 0;
}

static const struct i2c_device_id bd_id_table[] = {
	{ BD_DRV_NAME, 0 },
	{ }
};
MODULE_DEVICE_TABLE(i2c, bd_id_table);

static const struct of_device_id bd_of_match[] = {
	{ .compatible = "bd,bd1860" },
	{ }
};
MODULE_DEVICE_TABLE(of, bd_of_match);

static struct i2c_driver bd_driver = {
	.driver = {
		.name = BD_DRV_NAME,
		.of_match_table = bd_of_match,
	},
	.probe = bd_probe,
	.remove = bd_remove,
	.id_table = bd_id_table,
};
module_i2c_driver(bd_driver);

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("BD1860 heart-rate probe stub (W527 r42)");
