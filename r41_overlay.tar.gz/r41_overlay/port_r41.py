#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# r41 overlay: eta6947 charger enable + fgu floating-NTC temp fallback
# 1) config: CONFIG_CHARGER_ETA6947=y (driver/Kconfig/DTB all present in ZDC tree)
# 2) sc27xx_fuel_gauge.c: NTC pegged-high (floating) -> report 25.0C fallback

import os, re, sys

def must(cond, msg):
    if not cond:
        print("FAIL: " + msg)
        sys.exit(1)
    print("OK: " + msg)

fp = os.getcwd()

# ---------- 1. fgu floating-NTC temp fallback ----------
p = os.path.join(fp, "drivers/power/supply/sc27xx_fuel_gauge.c")
s = open(p, encoding="utf-8").read()
MARK = "W527-r41-ntc-fallback"
if MARK not in s:
    anchor = ("ret = iio_read_channel_processed(data->channel, &vol);\n"
              "\tif (ret < 0)\n"
              "\t\treturn ret;")
    cnt = s.count(anchor)
    must(cnt == 1, "fgu get_temp anchor found (count=%d)" % cnt)
    ins = (anchor + "\n"
           "\n"
           "\t/* " + MARK + ": NTC floating detection (W527 board has no NTC\n"
           "\t * fitted; ADC pegs high near 1850mV full-scale, reads ~4080/4095).\n"
           "\t * Report a safe fixed 25.0C so charge limiting and UI behave. */\n"
           "\tif (vol > 1750) {\n"
           "\t\t*temp = 250;\n"
           "\t\t*temp = sc27xx_fgu_get_average_temp(data, *temp);\n"
           "\t\treturn 0;\n"
           "\t}")
    s = s.replace(anchor, ins, 1)
    open(p, "w", encoding="utf-8", newline="\n").write(s)
s = open(p, encoding="utf-8").read()
must(MARK in s, "fgu NTC fallback patch present")
must(s.count("*temp = 250;") == 1, "fallback body unique")

# ---------- 2. config: enable eta6947 ----------
cfg = None
for c in ("../w527.config", "w527.config"):
    if os.path.exists(c):
        cfg = c
        break
must(cfg is not None, "config file located: " + str(cfg))
s = open(cfg, encoding="utf-8").read()
for k in ("CONFIG_CHARGER_ETA6947=y", "CONFIG_POWER_SUPPLY=y"):
    if k not in s:
        s = s.rstrip("\n") + "\n" + k + "\n"
        open(cfg, "w", encoding="utf-8", newline="\n").write(s)
s = open(cfg, encoding="utf-8").read()
must("CONFIG_CHARGER_ETA6947=y" in s, "CONFIG_CHARGER_ETA6947=y in config")

# ---------- 3. verify Kconfig entry exists ----------
p = os.path.join(fp, "drivers/power/supply/Kconfig")
s = open(p, encoding="utf-8").read()
must("CHARGER_ETA6947" in s, "Kconfig has CHARGER_ETA6947 entry")

print("r41 overlay done")
