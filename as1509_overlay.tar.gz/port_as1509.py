#!/usr/bin/env python3
"""port_as1509.py - mount as1509_i2c driver into ZDC uws6152 tree (idempotent)"""
import sys, os

def append(path, text, tag):
    s = open(path).read()
    key = text.strip().splitlines()[0]
    if key in s:
        print('%s already present' % tag)
        return
    if not s.endswith('\n'):
        s += '\n'
    open(path, 'a').write(text + '\n')
    print('%s appended' % tag)

root = sys.argv[1] if len(sys.argv) > 1 else '.'
kc = os.path.join(root, 'drivers/input/misc/Kconfig')
mk = os.path.join(root, 'drivers/input/misc/Makefile')

append(kc,
    'config INPUT_AS1509\n'
    '\ttristate "AS1509 magnetic rotary encoder (W527 crown)"\n'
    '\tdepends on I2C && INPUT\n'
    '\tdefault y\n'
    '\thelp\n'
    '\t  Say Y here to enable the AS1509 magnetic rotary encoder driver\n'
    '\t  used as the W527 smartwatch crown. Rewritten from factory ELF\n'
    '\t  symbol-level disassembly; angle-quadrant fallback when uncalibrated.\n',
    'as1509-kconfig')

append(mk, 'obj-$(CONFIG_INPUT_AS1509)\t+= as1509_i2c.o', 'as1509-makefile')

# verify
s = open(kc).read()
assert 'config INPUT_AS1509' in s
s = open(mk).read()
assert 'as1509_i2c.o' in s
print('as1509 mounted OK')
