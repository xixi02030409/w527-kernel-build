#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# r42 overlay: bd1860 heart-rate probe stub (i2c2@0x40, DTB ready)
# adds drivers/misc/bd1860/ + Kconfig/Makefile wiring + CONFIG_BD1860_PROBE=y

import os, re, sys

def must(cond, msg):
    if not cond:
        print("FAIL: " + msg)
        sys.exit(1)
    print("OK: " + msg)

fp = os.getcwd()
sd = os.path.join(fp, "drivers/misc/bd1860")
os.makedirs(sd, exist_ok=True)

# 1. driver source
src = open(os.path.join(fp, "r42_overlay/bd1860_probe.c"), encoding="utf-8").read()
open(os.path.join(sd, "bd1860_probe.c"), "w", encoding="utf-8", newline="\n").write(src)
must("bd,bd1860" in src, "driver source installed")

# 2. Kconfig
kc = ("menuconfig BD1860_PROBE\n"
      "\tbool \"BD1860 heart-rate probe stub (W527)\"\n"
      "\tdepends on I2C\n"
      "\tdefault y\n"
      "\thelp\n"
      "\t  BD1860 HR sensor probe stub: i2c liveness + reg dump/flash sysfs.\n")
open(os.path.join(sd, "Kconfig"), "w", encoding="utf-8", newline="\n").write(kc)

# 3. Makefile
mk = "obj-$(CONFIG_BD1860_PROBE) += bd1860_probe.o\n"
open(os.path.join(sd, "Makefile"), "w", encoding="utf-8", newline="\n").write(mk)

# 4. wire drivers/misc/Kconfig + Makefile
p = os.path.join(fp, "drivers/misc/Kconfig")
s = open(p, encoding="utf-8").read()
line = 'source "drivers/misc/bd1860/Kconfig"'
if line not in s:
    if 'source "drivers/misc/hxd019' in s:
        idx = s.find('source "drivers/misc/hxd019')
        idx = s.find("\n", idx) + 1
        s = s[:idx] + line + "\n" + s[idx:]
    else:
        s = s.rstrip("\n") + "\n" + line + "\n"
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must(line in open(p).read(), "misc/Kconfig sources bd1860")

p = os.path.join(fp, "drivers/misc/Makefile")
s = open(p, encoding="utf-8").read()
obj = "obj-$(CONFIG_BD1860_PROBE) += bd1860/"
if obj not in s:
    s = s.rstrip("\n") + "\n" + obj + "\n"
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must(obj in open(p).read(), "misc/Makefile has bd1860 obj")

# 5. config
cfg = None
for c in ("../w527.config", "w527.config"):
    if os.path.exists(c):
        cfg = c
        break
must(cfg is not None, "config located: " + str(cfg))
s = open(cfg, encoding="utf-8").read()
if "CONFIG_BD1860_PROBE=y" not in s:
    s = s.rstrip("\n") + "\nCONFIG_BD1860_PROBE=y\n"
    open(cfg, "w", encoding="utf-8", newline="\n").write(s)
must("CONFIG_BD1860_PROBE=y" in open(cfg).read(), "CONFIG_BD1860_PROBE=y")

print("r42 overlay done")
