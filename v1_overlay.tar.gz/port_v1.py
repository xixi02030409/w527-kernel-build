#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# r56 v1 overlay port script (run from source/ root, overlay extracted to v1_overlay/)
# Scope (v1 裸基线, 审核单 2026-11-05 批准):
#   1) eta6947-charger.c -> r54 factory-aligned full replacement (md5 ed59a03b lineage)
#   2) fgu present force (r35 lineage, build44 inline patch verbatim) - probe + IRQ
#   3) fgu floating-NTC fallback + TEMP guard 250 (r41b, port_r41.py verbatim)
#   4) qmc6308 + mir3da dir Kconfig/Makefile + misc wiring (bd1860-style, idempotent)
# NOT in scope: 336patch / abi fixes / bfq / erratum / bd1860 / fingerprint / IR / as1509

import os, sys

def must(cond, msg):
    if not cond:
        print("FAIL: " + msg)
        sys.exit(1)
    print("OK: " + msg)

fp = os.getcwd()

# ---------- 1. eta6947-charger.c full replacement (r54 factory-aligned) ----------
src = open(os.path.join(fp, "v1_overlay/eta6947-charger.c"), encoding="utf-8").read()
must("psy_changed_throttled" in src, "eta r54 marker present in overlay file")
open(os.path.join(fp, "drivers/power/supply/eta6947-charger.c"), "w", encoding="utf-8", newline="\n").write(src)
must("psy_changed_throttled" in open(os.path.join(fp, "drivers/power/supply/eta6947-charger.c")).read(), "eta6947-charger.c replaced with r54 version")

kc = open(os.path.join(fp, "drivers/power/supply/Kconfig"), encoding="utf-8").read()
must("CHARGER_ETA6947" in kc, "tree Kconfig has CHARGER_ETA6947 entry (ZDC built-in)")
mk = open(os.path.join(fp, "drivers/power/supply/Makefile"), encoding="utf-8").read()
must("eta6947-charger.o" in mk, "tree Makefile has eta6947-charger.o obj")

# ---------- 2. fgu present force (r35 lineage; build44 inline patch verbatim) ----------
p = os.path.join(fp, "drivers/power/supply/sc27xx_fuel_gauge.c")
s = open(p, encoding="utf-8").read()

def replace_once(text, old, new, tag):
    n = text.count(old)
    must(n == 1, "%s: anchor matched %d times (expect 1)" % (tag, n))
    return text.replace(old, new)

s = replace_once(s,
    "\tdata->bat_present = !!ret;",
    "\t/* W527: non-removable battery, bat-detect pin (PMIC EIC #3) reads lo\n"
    "\t * while factory reports present=1 -> GPIO level untrusted.\n"
    "\t * present=0 blocks eta6947 charging (Not charging, ICL pinned 0). */\n"
    "\tdev_info(&pdev->dev, \"W527 bat-detect raw=%d, force present=1\\n\", ret);\n"
    "\tdata->bat_present = true;",
    "fgu probe present")

s = replace_once(s,
    "\tdata->bat_present = !!state;",
    "\t/* W527: non-removable battery, see probe comment */\n"
    "\tdata->bat_present = true;",
    "fgu irq present")

open(p, "w", encoding="utf-8", newline="\n").write(s)
s = open(p, encoding="utf-8").read()
must(s.count("bat_present = true") >= 2, "fgu both present sites forced true")
must(s.count("bat_present = !!") == 0, "fgu raw bat_present assignments all gone")

# ---------- 3. fgu floating-NTC fallback (r41b verbatim) ----------
MARK = "W527-r41b-ntc-fallback"
if MARK not in s:
    anchor = ("ret = iio_read_channel_processed(data->channel, &vol);\n"
              "\tif (ret < 0)\n"
              "\t\treturn ret;")
    s = replace_once(s, anchor,
        anchor + "\n"
        "\n"
        "\t/* " + MARK + ": NTC floating detection (W527 board has no NTC\n"
        "\t * fitted; ADC pegs high near 1850mV full-scale, reads ~4080/4095).\n"
        "\t * Report a safe fixed 25.0C so charge limiting and UI behave. */\n"
        "\tif (vol > 1750 || vol < 50) {\n"
        "\t\t*temp = 250;\n"
        "\t\t*temp = sc27xx_fgu_get_average_temp(data, *temp);\n"
        "\t\treturn 0;\n"
        "\t}",
        "fgu get_temp NTC anchor")
    open(p, "w", encoding="utf-8", newline="\n").write(s)
s = open(p, encoding="utf-8").read()
must(MARK in s, "fgu NTC fallback patch present")
must(s.count("*temp = 250;") == 1, "fallback body unique")

# TEMP hardcode 200 -> 250 (DTB temp table missing guard, r41b)
p = os.path.join(fp, "drivers/power/supply/sc27xx_fuel_gauge.c")
s = open(p, encoding="utf-8").read()
if "val->intval = 250;" not in s:
    s = replace_once(s, "val->intval = 200;",
        "val->intval = 250; /* W527-r41b: no NTC table in DTB; report safe 25.0C */",
        "TEMP hardcode")
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must("val->intval = 250;" in open(p).read(), "TEMP guard now 250")

# ---------- 4. qmc6308 + mir3da wiring (bd1860-style, idempotent) ----------
sd = os.path.join(fp, "drivers/input/misc/qmc6308")
must(os.path.isfile(os.path.join(sd, "qmc6308.c")), "qmc6308 source present (drivers_overlay.tar.gz)")
must(os.path.isfile(os.path.join(fp, "drivers/input/misc/mir3da/mir3da_core.c")), "mir3da source present")

qc = ("config SENSORS_QMC6308\n"
      "\tbool \"QMC6308 magnetic sensor (W527)\"\n"
      "\tdepends on I2C\n"
      "\tdefault y\n"
      "\thelp\n"
      "\t  QMC6308 compass for W527 (compatible \"qmc,qmc6308\").\n")
open(os.path.join(sd, "Kconfig"), "w", encoding="utf-8", newline="\n").write(qc)
open(os.path.join(sd, "Makefile"), "w", encoding="utf-8", newline="\n").write(
    "obj-$(CONFIG_SENSORS_QMC6308) += qmc6308.o\n")

md = os.path.join(fp, "drivers/input/misc/mir3da")
mc = ("config SENSORS_MIR3DA\n"
      "\tbool \"mir3da/da21x gsensor (W527)\"\n"
      "\tdepends on I2C\n"
      "\tdefault y\n"
      "\thelp\n"
      "\t  MiraSensor gsensor for W527 (legacy i2c board info registration).\n")
open(os.path.join(md, "Kconfig"), "w", encoding="utf-8", newline="\n").write(mc)
open(os.path.join(md, "Makefile"), "w", encoding="utf-8", newline="\n").write(
    "obj-$(CONFIG_SENSORS_MIR3DA) += mir3da.o\n"
    "mir3da-objs := mir3da_core.o mir3da_cust.o\n")

p = os.path.join(fp, "drivers/input/misc/Kconfig")
s = open(p, encoding="utf-8").read()
changed = False
for line in ('source "drivers/input/misc/qmc6308/Kconfig"',
             'source "drivers/input/misc/mir3da/Kconfig"'):
    if line not in s:
        s = s.rstrip("\n") + "\n" + line + "\n"
        changed = True
if changed:
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must('source "drivers/input/misc/qmc6308/Kconfig"' in open(p).read(), "misc/Kconfig sources qmc6308")
must('source "drivers/input/misc/mir3da/Kconfig"' in open(p).read(), "misc/Kconfig sources mir3da")

p = os.path.join(fp, "drivers/input/misc/Makefile")
s = open(p, encoding="utf-8").read()
changed = False
for line in ("obj-$(CONFIG_SENSORS_QMC6308) += qmc6308/",
             "obj-$(CONFIG_SENSORS_MIR3DA) += mir3da/"):
    if line not in s:
        s = s.rstrip("\n") + "\n" + line + "\n"
        changed = True
if changed:
    open(p, "w", encoding="utf-8", newline="\n").write(s)
must("obj-$(CONFIG_SENSORS_QMC6308) += qmc6308/" in open(p).read(), "misc/Makefile has qmc6308 obj")
must("obj-$(CONFIG_SENSORS_MIR3DA) += mir3da/" in open(p).read(), "misc/Makefile has mir3da obj")

# ---------- 5. final cross-verify ----------
must("qmc,qmc6308" in open(os.path.join(sd, "qmc6308.c")).read(), "qmc6308 compatible intact")
print("v1 overlay done: eta r54 + fgu present/NTC + qmc6308/mir3da wired")
